# justc-nixos installation audit

Review date: 2026-07-23

## Outcome

The supplied package was not safe to run unchanged. The reviewed v9 package
corrects the blocking configuration errors and changes the reinstall flow so
that a failed build does not cost the existing root.

The installer still needs to run on the actual laptop to complete the only
checks that cannot be reproduced elsewhere: unlock the real LUKS container,
generate its hardware configuration, lock/fetch the live inputs, build the
full closure, install the bootloader, and validate against the actual disk.
Those checks now happen in the script, with the full build occurring before
the root switch.

## Original files reviewed

| File | SHA-256 |
|---|---|
| `justc-nixos-handoff-v4.pdf` | `b7edf5553052ab6d21168a8396d91698bcc3fddc5f08f40fcfb6b4886ac3ed2c` |
| `justc-nixos.zip` | `67b29b5725750624e90569ab22920cc8b9d582b0da24839eca70f3a0c9356895` |
| `install.sh` | `71157cf5a25f06cc3603712d6f210b0ae490a73e6f8cf929e417faf1f8b371f7` |

The ZIP passed its CRC/integrity test. Its embedded installer was byte-for-byte
identical to the standalone installer.

## Material findings and fixes

| Severity | Finding in supplied files | Resolution in reviewed package |
|---|---|---|
| Critical | First global `crypto_LUKS` device was selected, so another encrypted drive could be targeted. | Require exactly one `disk-main-luks`, its sibling `disk-main-esp`, expected size, no NTFS, and show model/serial. |
| Critical | Existing `cryptroot` mapping was trusted without checking its source. | Compare the mapper's underlying canonical device with the verified LUKS partition. |
| Critical | A dry run was described as proving the build, but it did not fetch or build the closure. | Activate temporary swap and run a real `nix build --no-link` in the preserved target Nix store before root replacement. |
| Critical | Old `@` was permanently deleted before installation. | Rename it to `@rollback-<timestamp>`, protect its system closure with a GC root, and automatically restore it on a critical failure. |
| Critical | Known login password was stored as `initialPassword`, exposing it through source and the Nix store. | Remove it and run interactive `passwd` inside the installed system. |
| High | All packages marked insecure by nixpkgs were globally accepted. | Remove the unrestricted predicate; guarded packages are skipped/reported, while an unguarded insecure dependency fails the safe preflight build for an explicit decision. |
| High | Niri used obsolete `blur { on }` syntax. | Use current `background-effect { blur true }` and validate before confirmation and after installation with the built niri binary. |
| High | ESP files were removed without a complete recovery copy. | Copy the dedicated NixOS ESP into preserved `@nix` before cleaning known NixOS paths. |
| High | Expected GPT labels were only printed after destructive work. | Make exact labels mandatory before unlock or build. |
| High | Existing home was recursively changed to UID/GID 1000:100. | Verify the preserved home UID, set the user UID explicitly, and chown only newly copied config/backup paths. |
| Medium | Dotfile targets were removed with only one fixed `.bak`. | Create a fresh timestamped backup tree on every run and reject targets outside `$HOME`. |
| Medium | Limine kept eight large NVIDIA generations on a 1 GB ESP. | Keep five generations and install the removable fallback EFI path. |
| Medium | Limine `term_background` used six digits although current documentation specifies `TTRRGGBB`. | Use `000b0d11`. |
| Medium | The nix-software-center input used its former repository owner and generic output. | Use `snowfallorg/nix-software-center` and its named package output. |
| Medium | Windows discovery started from the first NTFS partition. | Scan FAT partitions on other NTFS-bearing disks and accept only a unique ESP containing Microsoft's boot manager. |
| Medium | Failure instructions depended on rerunning a clone command that discarded local edits. | Ship explicit recovery instructions and preserve the installed, locked config in `~/nixos`. |
| Medium | A reviewed standalone installer could accidentally pick up an older extracted `justc-nixos/` directory beside it. | Prefer the reviewed ZIP and require an exact v9 review marker before any disk discovery. |
| Medium | A valid existing NixOS root using `system.etc.overlay` may not contain `/etc/NIXOS`, causing a safe but incorrect refusal. | Resolve the preserved system profile to an exact `nixos-system` store closure and verify that closure's `os-release` identifies NixOS. |
| Low | The power menu's lock entry was an empty string, so cancelling the menu could match “lock.” | Give the lock action an explicit icon and leave an empty cancellation unmatched. |

## Documentation reconciliation

The handoff PDF and archive disagreed:

- the PDF described installer v7 while the supplied script was v8;
- the PDF said nixvim/`nvix` was enabled, while the archive had removed it;
- the PDF described an active Ghostty starfield, while the archive had it off;
- the Markdown guides still described a blank-disk Disko install, USB-key
  unlock, an obsolete preset password, and old Windows-entry steps.

The v9 Markdown files are now the canonical instructions. The PDF is retained
only as historical handoff context.

## Static validation completed

- archive path and symlink audit;
- ZIP CRC test;
- Bash syntax check for every shell script;
- ShellCheck warning-level pass for every shell script;
- JSON/JSONC, CSS/SCSS, and TOML parser passes;
- Nix parser pass for every `.nix` file;
- safe no-hardware execution of Waybar/Eww helper scripts and validation of
  their fallback outputs;
- cross-reference scan for shipped paths, plaintext passwords, stale
  installer claims, and destructive commands;
- visual rendering and inspection of all eight PDF pages.

Nix itself is not installed in the review environment, so a semantic flake
evaluation could not be honestly claimed here. The v9 installer compensates
by doing both option evaluation and a real full build from the live NixOS USB,
directly into the target's preserved Nix store, before the typed destructive
confirmation.

## Assumptions enforced at runtime

- target is the existing approximately 1 TB NixOS SSD;
- partition labels are `disk-main-luks` and `disk-main-esp`;
- the current root is NixOS on Btrfs subvolume `@`;
- `@home`, `@nix`, and `@snapshots` must be preserved;
- user is `lovergirlonline`, UID 1000;
- Windows is on a separate SSD.

If any assumption is wrong, do not bypass the refusal. Stop and adjust the
reviewed plan to the machine's real layout.

## Remaining runtime-specific risks

- Limine's Windows entry is convenience-only; use the firmware F12 menu as the
  reliable Windows path.
- PRIME bus IDs in `graphics.nix` must be checked once in BIOS Hybrid mode.
- Fingerprint, OpenRGB, and Lenovo-specific controls depend on the exact
  device firmware.
- Third-party flakes and binary caches can change or be unavailable. The real
  preflight build catches this before the root switch.
- Cloudflare WARP can have release-specific tunnel regressions. Mullvad is the
  safer fallback until WARP is confirmed on this build.

Authoritative references used for current syntax and install behavior:

- NixOS manual: <https://nixos.org/manual/nixos/stable/>
- NixOS release notes: <https://nixos.org/manual/nixos/stable/release-notes>
- niri configuration: <https://niri-wm.github.io/niri/Configuration:-Introduction.html>
- niri window effects: <https://github.com/niri-wm/niri/wiki/Window-Effects>
- Limine configuration: <https://github.com/Limine-Bootloader/Limine/blob/v12.x/CONFIG.md>
- Ghostty configuration: <https://ghostty.org/docs/config/reference>
