# Simple install guide

This is for reinstalling the existing encrypted NixOS SSD while keeping
`/home`, `/nix`, and snapshots. It is not for a blank or newly partitioned
disk.

## Before starting

Have:

1. a NixOS 26.05 graphical installer USB;
2. `lovergirlcfg-install.sh` and `lovergirlcfg.zip` together on
   another drive or downloaded into the live session;
3. the existing LUKS passphrase;
4. enough time for a complete NixOS build.

Windows must remain on its separate SSD. Secure Boot must be off for this
Limine configuration.

## Run it

Boot the installer USB with F12, connect to Wi-Fi, open Konsole, and change to
the directory containing both files. For example:

```bash
cd ~/Downloads
bash lovergirlcfg-install.sh
```

Do not run the old manual Disko `destroy,format,mount` command. That is only for
creating a disk from scratch and would erase the preserved subvolumes.

## Prompts you will see

1. The LUKS passphrase. Nothing appears while you type it.
2. A long full-system build. The old root still exists during this phase.
3. A target summary showing the SSD path, model, serial, and partitions.
4. The exact confirmation phrase:

   ```text
   REINSTALL justc
   ```

5. The new login password for `lovergirlonline`. Choose it twice. It is not a
   preset password and is not written into the configuration.

The confirmation prompt appears only after the full build succeeds.

## When it finishes

Run:

```bash
sudo reboot
```

Remove the installer USB as the machine restarts. In Limine, start NixOS,
enter the LUKS passphrase, then log in as `lovergirlonline` using the password
you created.

Test niri and Plasma, networking, sound, suspend/resume, NVIDIA, a second
reboot, and Windows through F12. Keep the reported `@rollback-…` root and the
ESP backup until those checks pass.

If the installer stops before “INSTALL COMPLETE,” follow the message on screen.
If it says automatic rollback failed, do not reboot; use
[RECOVERY.md](RECOVERY.md).
