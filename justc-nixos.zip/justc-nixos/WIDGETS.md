# Widgets — what's already on, and what you can add

## Already wired up in this revision

Nine new modules are live in `dotfiles/waybar/config.jsonc`. Four are
built into waybar (no external code); four are small scripts in
`dotfiles/waybar/scripts/`.

| Module | Source | Notes |
|---|---|---|
| `privacy` | waybar built-in | red dot when something is screensharing or using the mic |
| `idle_inhibitor` | waybar built-in | caffeine. Click to keep the screen awake |
| `cpu` / `temperature` / `memory` | waybar built-in | click opens btop |
| `custom/gpu` | `scripts/gpu.sh` | 4070 util / temp / VRAM via nvidia-smi. Click opens nvtop |
| `custom/vpn` | `scripts/vpn.sh` | one indicator for both tunnels; **turns red if Mullvad and WARP are both up**. Left click = Mullvad, right click = WARP, and each refuses if the other is connected |
| `custom/powerprofile` | `scripts/powerprofile.sh` | quiet / balanced / perf, click cycles |
| `custom/conserve` | `scripts/conserve.sh` | your battery charge cap, click toggles |

**Read this before installing anything below:** waybar already ships
`clock`, `tray`, `battery`, `network`, `bluetooth`, `disk`, `memory`, `cpu`,
`temperature`, `mpris`, `keyboard-state`, `privacy`, `idle_inhibitor`,
`gamemode` and `systemd-failed-units`. Don't add a repo for something that
is one config block away.

## Custom widgets on GitHub

The big caveat: **most waybar module collections are written for Arch.**
Anything that shells out to `pacman`, `checkupdates`, `paru` or `yay` is
dead on arrival here. The useful ones are the DBus/sysfs-based modules.

| Repo | What's worth taking | Works on NixOS? |
|---|---|---|
| `Ferdi265/waybar_custom_modules` | power profile via the UPower DBus service; a "running kernel ≠ installed kernel, reboot me" indicator | Yes — both are DBus/sysfs. The reboot-needed one is genuinely useful with Nix generations |
| `sl424/waybar` | C modules; includes a VPN module written specifically against Mullvad, and a battery module showing live watts | Yes, but you'd compile them. Our `vpn.sh` already covers the Mullvad case |
| `SirAllap/waybar-scripts-collection` | clock+weather+moon phase in one, network bandwidth + wifi signal, storage with SMART data | Mostly. Its GPU script is **AMD-only** — ours is the nvidia one. Needs `python3` + `psutil` added to `modules/desktop.nix` |
| `peteonrails/waybar-addons` | Tempest weather (needs your own station + API token), do-not-disturb toggle, dynamic workspace icons | Weather and DND yes; the workspace script is Hyprland-specific and won't drive niri |
| `thnikk/waybar-modules` | clock with a calendar-events tooltip, OBS scene/recording status | Clock yes. Its updates module is pacman-based — skip |
| `github.com/topics/waybar-module` | browse everything tagged | Filter hard for non-Arch |

### Adding one, concretely

1. Drop the script in `~/nixos/dotfiles/waybar/scripts/`
2. Add its `custom/<name>` block to `dotfiles/waybar/config.jsonc`
3. Add `<name>` to `modules-right`
4. Style `#custom-<name>` in `dotfiles/waybar/style.css` — the shared
   selector near the top is the raised-face look; add your ID to that list
5. Any binary it needs goes in `modules/desktop.nix` → `environment.systemPackages`
6. `bash ~/nixos/dotfiles/link.sh` then `bar`

### Ideas that need no repo at all

- **`mpris`** — now-playing in the bar. Built in, one config block, and you
  already run playerctl.
- **`systemd-failed-units`** — quietly tells you when a unit died. Built in.
- **`gamemode`** — shows when gamemode is active. Built in, and you already
  have `programs.gamemode.enable`.
- **`custom/updates`** — `nix flake check` style "your flake is N days old"
  indicator. There's no good Nix one packaged; it's about 10 lines of shell
  against `nix flake metadata --json`.

## Plasma widgets (the KDE session)

Different system entirely — plasmoids, not waybar. Since you're now on
Plasma 6.7:

- `kdePackages.plasma-systemmonitor` — proper system monitor
- Right click panel → Add Widgets → Get New Widgets pulls from store.kde.org.
  These install into `~/.local/share/plasma/plasmoids/` and are **not**
  managed by Nix — they survive rebuilds but not a fresh `@` subvolume, so
  note down any you rely on.
- Plasma 6.7 additions worth knowing about: the Brightness & Color widget
  gained a light/dark toggle, and there's a global push-to-talk shortcut.
