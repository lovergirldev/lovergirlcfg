{ config, pkgs, lib, ... }:

{
  # ---------- Default: dGPU-always (BIOS set to Discrete/dGPU-only) ----------
  # The 4070 drives the internal 240Hz panel directly -> reliable VRR.
  services.xserver.videoDrivers = [ "nvidia" ];

  hardware.graphics = {
    enable = true;
    enable32Bit = true;   # Steam/Proton needs 32-bit GL/Vulkan
  };

  hardware.nvidia = {
    modesetting.enable = true;
    open = true;                     # open kernel modules — correct choice for Ada (RTX 40)
    nvidiaSettings = true;
    powerManagement.enable = true;   # saves VRAM across suspend -> reliable sleep/resume
    dynamicBoost.enable = true;      # CPU<->GPU power shifting on laptops
    # Driver branch: nixpkgs default (production) is fine. If you ever want
    # the newest: package = config.boot.kernelPackages.nvidiaPackages.latest;
  };

  # ---------- "hybrid" boot-menu entry (travel/battery days) ----------
  # Usage: reboot -> BIOS -> switch graphics to Hybrid -> pick the (hybrid)
  # entry in the boot menu. iGPU renders by default; prefix a command with
  # `nvidia-offload` to run it on the 4070.
  specialisation.hybrid.configuration = {
    system.nixos.tags = [ "hybrid" ];
    hardware.nvidia = {
      powerManagement.finegrained = true;   # lets the 4070 power-gate when idle
      prime = {
        offload = {
          enable = true;
          enableOffloadCmd = true;   # provides the `nvidia-offload` wrapper
        };
        # !!! CHANGEME #4 (verify once, before first hybrid boot):
        # in Hybrid BIOS mode run  lspci | grep -Ei 'vga|3d'
        # 00:02.0 -> "PCI:0:2:0" (Intel), 01:00.0 -> "PCI:1:0:0" (NVIDIA).
        # These defaults are correct on almost every Legion; just confirm.
        intelBusId = "PCI:0:2:0";
        nvidiaBusId = "PCI:1:0:0";
      };
    };
  };
}
