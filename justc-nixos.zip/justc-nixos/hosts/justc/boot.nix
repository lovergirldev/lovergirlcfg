{ config, pkgs, lib, ... }:

let
  # ------------------------------------------------------------------
  # ONE SWITCH: which bootloader.
  #
  # "limine"       = Limine (new default)
  # "systemd-boot" = the old loader, byte-for-byte what you had before
  #
  # If Limine ever fails to install or the machine won't boot, change this
  # one word and re-run the installer (or `nrs` from a live USB chroot).
  # ------------------------------------------------------------------
  loader = "limine";

  # Windows 11 lives on the OTHER SSD, on its own ESP.
  # install.sh detects that partition's filesystem UUID and rewrites the line
  # below automatically, so you should never have to touch it. Addressing it
  # by UUID is deliberate: it is immune to the nvme0/nvme1 name swap that has
  # bitten this machine repeatedly. "CHANGEME" means detection did not run.
  windowsEspUuid = "CHANGEME";
  haveWindows = windowsEspUuid != "CHANGEME";
in
{
  boot.loader.efi.canTouchEfiVariables = true;

  # ---------------- Limine ----------------
  boot.loader.limine = lib.mkIf (loader == "limine") {
    enable = true;
    efiSupport = true;

    # Your ESP is 1 GB. Each generation stores a kernel + an initrd, and the
    # nvidia initrd is fat (~130 MB a piece). 8 generations is about 1 GB with
    # a little headroom. Raising this is how you fill the ESP and get a
    # confusing "No space left on device" mid-rebuild.
    maxGenerations = 8;

    # Boot menu styling — ink + amber, to match everything else.
    extraConfig = ''
      timeout: 3
      default_entry: 1
      interface_branding: justc
      term_palette: 0b0d11;e5715c;86c9a0;f3b8d1;7fa9d6;b89ad9;86c7c7;e3e5ea
      term_palette_bright: 3a3f4b;f2836d;99d9b0;fad4e6;92bce8;c9adea;98d8d8;ffffff
      term_background: 0b0d11
      term_foreground: e3e5ea
    '';

    # Windows chainload. uuid() points Limine at the Windows ESP by filesystem
    # UUID, on whichever disk it happens to be this boot.
    extraEntries = lib.optionalString haveWindows ''
      /Windows 11
          comment: Windows 11 on the second SSD
          protocol: efi
          path: uuid(${windowsEspUuid}):/EFI/Microsoft/Boot/bootmgfw.efi
    '';
  };

  # ---------------- systemd-boot (fallback) ----------------
  boot.loader.systemd-boot = lib.mkIf (loader == "systemd-boot") {
    enable = true;
    configurationLimit = 8;
    edk2-uefi-shell.enable = true;
  };

  # Newest kernel — 13th-gen HX + RTX 40 hardware wants it.
  boot.kernelPackages = pkgs.linuxPackages_latest;

  # Modern systemd-based initrd: clean keyfile->passphrase fallback.
  boot.initrd.systemd.enable = true;

  # LUKS unlock is PASSPHRASE-ONLY (disko.nix sets up the device).
  # To add a USB key later, uncomment and set the by-id path:
  #
  # boot.initrd.luks.devices."cryptroot" = {
  #   keyFile = "/dev/disk/by-id/usb-CHANGEME";
  #   keyFileSize = 4096;
  #   keyFileOffset = 10485760;
  #   crypttabExtraOpts = [ "keyfile-timeout=10s" ];
  # };

  # 16 GB RAM, no hibernation -> compressed RAM swap instead of a disk partition.
  zramSwap = {
    enable = true;
    memoryPercent = 50;
  };

  # Read the Windows drive from Linux if you ever want to.
  boot.supportedFilesystems = [ "ntfs" ];
}
