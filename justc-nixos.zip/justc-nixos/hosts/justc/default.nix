{ config, pkgs, lib, inputs, ... }:

let
  # ------------------------------------------------------------------
  # ONE SWITCH: Plasma 6.7 from unstable.
  #
  # true  = KDE comes from nixpkgs-unstable (Plasma 6.7.x, Qt 6.10)
  # false = KDE comes from 26.05 stable    (Plasma 6.6.x, Qt 6.9)
  #
  # Plasma is your escape hatch when niri misbehaves, so if Qt apps start
  # crashing or SDDM black-screens after an update, flip this to false and
  # run `nrs`. That is the whole revert — nothing else references it.
  # ------------------------------------------------------------------
  plasmaUnstable = true;
in
{
  imports = [
    ./disko.nix
    ./hardware-configuration.nix   # stub — REPLACED on install day
    ./boot.nix
    ./graphics.nix
    ./legion.nix
    ../../modules/desktop.nix
    ../../modules/apps.nix
    ../../modules/nixvim.nix
    ../../modules/extras.nix
    ../../modules/gaming.nix
    ../../modules/network-vpn.nix
    ../../modules/shell.nix
    ../../modules/services.nix
  ];

  networking.hostName = "justc";

  time.timeZone = "America/New_York";
  i18n.defaultLocale = "en_US.UTF-8";
  console.keyMap = "us";

  users.users.lovergirlonline = {
    isNormalUser = true;
    description = "lovergirlonline";
    extraGroups = [ "wheel" "networkmanager" "video" "input" "lp" "scanner" ];
    shell = pkgs.fish;
    initialPassword = "fern2424";   # run `passwd` at first login
  };

  nixpkgs.config.allowUnfree = true;
  nixpkgs.config.allowInsecurePredicate = pkg: true;

  # ---------------- overlays ----------------
  nixpkgs.overlays = [
    (final: prev: {
      unstable = import inputs.nixpkgs-unstable {
        system = prev.stdenv.hostPlatform.system;
        config = { allowUnfree = true; allowInsecurePredicate = pkg: true; };
      };
      # niri 26.04+ is what gives us window/layer blur; keep it on unstable.
      niri = final.unstable.niri;
      xwayland-satellite = final.unstable.xwayland-satellite;
    })

    # BUGFIX 1a: affinity-nix's own README says to install via their overlay,
    # because the package is unfree and referencing it directly through
    # inputs.<>.packages is what keeps tripping the unfree gate. This is that
    # overlay. It gives us pkgs.affinity-v3.
    inputs.affinity-nix.overlays.default

    # NUR — community packages at pkgs.nur.repos.<user>.<package>
    inputs.nur.overlays.default
  ]
  # Plasma 6.7. Overlaying the whole kdePackages scope also moves SDDM and
  # Qt 6.10 with it, which is what Plasma 6.7 needs.
  ++ lib.optional plasmaUnstable (final: prev: {
    kdePackages = final.unstable.kdePackages;
  });

  # ---------------- nix daemon ----------------
  nix.settings = {
    experimental-features = [ "nix-command" "flakes" ];
    auto-optimise-store = true;

    # BUGFIX (component d): without this, Flatpak, cachix and any
    # user-level substituter silently do nothing.
    trusted-users = [ "root" "@wheel" ];

    # BUGFIX 1b: THE BIG ONE.
    # affinity-nix builds on garnix and their README says to add garnix as a
    # substituter "to avoid compiling yourself". Without this line, installing
    # Affinity compiles a patched Wine from source — that is the multi-hour
    # build you were warned about. nix-community covers nixvim and NUR.
    substituters = [
      "https://cache.nixos.org"
      "https://cache.garnix.io"
      "https://nix-community.cachix.org"
    ];
    trusted-public-keys = [
      "cache.nixos.org-1:6NCHdD59X431o0gWypbMrAURkbJ16ZPMQFGspcDShjY="
      "cache.garnix.io:CTFPyKSLcx5RMJKfLo5EEPUObbA78b0YQ2DTCJXqr9g="
      "nix-community.cachix.org-1:mB9FSh9qf2dCimDSUo8Zy7bkq5CX+/rkCWyvRCYg3Fs="
    ];

    # If a cache is down, build instead of hanging.
    connect-timeout = 5;
    fallback = true;
  };

  nix.gc = {
    automatic = true;
    dates = "weekly";
    options = "--delete-older-than 14d";
  };

  # Never change this after install, even on upgrades.
  system.stateVersion = "26.05";
}
