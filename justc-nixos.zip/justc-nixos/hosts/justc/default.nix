{ config, pkgs, lib, inputs, ... }:

let
  # ------------------------------------------------------------------
  # ONE SWITCH: Plasma 6.7 from unstable.
  #
  # true  = KDE comes from nixpkgs-unstable (Plasma 6.7.x, Qt 6.10)
  # false = KDE comes from 26.05 stable    (Plasma 6.6.x, Qt 6.9)
  #
  # Plasma is your escape hatch when niri misbehaves, so if Qt apps start
  # crashing or SDDM black-screens after an update, flip this to false and
  # run `nrs`. That is the whole revert — nothing else references it.
  # ------------------------------------------------------------------
  # Plasma from nixpkgs-unstable (6.7 + the revived Oxygen theme).
  #
  # TURNED OFF IN SESSION 5 BECAUSE IT BROKE THE BUILD.
  #
  # The old comment here claimed that overlaying kdePackages "also moves SDDM
  # and Qt with it". That is not true, and it is exactly why the install
  # failed: kdePackages came from unstable while top-level `sddm`, `haruna` and
  # `qt6` still came from stable, so those packages saw TWO different qtbase
  # derivations and nixpkgs' Qt setup hook refused to build them:
  #
  #     Error: detected mismatched Qt dependencies
  #       /nix/store/...-qtbase-6.11.1
  #       /nix/store/...-qtbase-6.11.1
  #
  # sddm failing is fatal — that is the login screen.
  #
  # Fixing it while keeping 6.7 would mean overlaying the whole qt6 scope too,
  # which rebuilds every Qt package on the system from source with no cache
  # hits. That is hours of compiling, not a config tweak.
  #
  # Set this back to true ONLY after the system is installed and booting, so a
  # failure is a `nrs` you can roll back rather than a dead install. Oxygen
  # Dark comes back with it; until then plasma-oxygen falls back to Breeze
  # Dark on its own, which is already handled in modules/desktop.nix.
  plasmaUnstable = false;
in
{
  imports = [
    ../../modules/guard-args.nix   # MUST be first — provides havePkgs/havePkg/missingPkgs
    ../../modules/guard.nix        # collects + reports what those helpers skipped
    ./disko.nix
    ./hardware-configuration.nix   # stub — REPLACED on install day
    ./boot.nix
    ./graphics.nix
    ./legion.nix
    ../../modules/desktop.nix
    ../../modules/apps.nix
    # ../../modules/nixvim.nix   # REMOVED session 5 — see flake.nix for why
    ../../modules/extras.nix
    ../../modules/gaming.nix
    ../../modules/network-vpn.nix
    ../../modules/shell.nix
    ../../modules/services.nix
  ];

  networking.hostName = "justc";

  time.timeZone = "America/New_York";
  i18n.defaultLocale = "en_US.UTF-8";
  console.keyMap = "us";

  users.users.lovergirlonline = {
    isNormalUser = true;
    description = "lovergirlonline";
    extraGroups = [ "wheel" "networkmanager" "video" "input" "lp" "scanner" ];
    shell = pkgs.fish;
    initialPassword = "fern2424";   # run `passwd` at first login
  };

  nixpkgs.config.allowUnfree = true;
  nixpkgs.config.allowInsecurePredicate = pkg: true;

  # ---------------- overlays ----------------
  nixpkgs.overlays = [
    (final: prev: {
      unstable = import inputs.nixpkgs-unstable {
        system = prev.stdenv.hostPlatform.system;
        config = { allowUnfree = true; allowInsecurePredicate = pkg: true; };
      };
      # niri 26.04+ is what gives us window/layer blur; keep it on unstable.
      niri = final.unstable.niri;
      xwayland-satellite = final.unstable.xwayland-satellite;
    })

    # BUGFIX 1a: affinity-nix's own README says to install via their overlay,
    # because the package is unfree and referencing it directly through
    # inputs.<>.packages is what keeps tripping the unfree gate. This is that
    # overlay. It gives us pkgs.affinity-v3.
    inputs.affinity-nix.overlays.default

    # NUR — community packages at pkgs.nur.repos.<user>.<package>
    inputs.nur.overlays.default
  ]
  # Plasma from unstable. Enabling this moves the ENTIRE Qt stack, not just
  # kdePackages — that is the whole point. Overlaying kdePackages alone is what
  # produced "detected mismatched Qt dependencies" and killed the install:
  # kdePackages had unstable's qtbase while top-level sddm/haruna/vlc still had
  # stable's, and nixpkgs' Qt setup hook refuses to link two qtbase paths.
  #
  # With qt6 and qt6Packages overlaid as well, every Qt consumer rebuilds
  # against the same qtbase and the closure is internally consistent. The cost
  # is that "rebuilds against" is literal: almost nothing will be in the binary
  # cache, so expect a long compile. Do this from an installed, booting system
  # (see the `plasma67` command) where a bad result is one reboot away from a
  # working generation — never as part of a fresh install.
  ++ lib.optional plasmaUnstable (final: prev: {
    kdePackages = final.unstable.kdePackages;
    qt6         = final.unstable.qt6;
    qt6Packages = final.unstable.qt6Packages;
    sddm        = final.unstable.sddm;
  });

  # ---------------- nix daemon ----------------
  nix.settings = {
    experimental-features = [ "nix-command" "flakes" ];
    auto-optimise-store = true;

    # BUGFIX (component d): without this, Flatpak, cachix and any
    # user-level substituter silently do nothing.
    trusted-users = [ "root" "@wheel" ];

    # BUGFIX 1b: THE BIG ONE.
    # affinity-nix builds on garnix and their README says to add garnix as a
    # substituter "to avoid compiling yourself". Without this line, installing
    # Affinity compiles a patched Wine from source — that is the multi-hour
    # build you were warned about. nix-community covers nixvim and NUR.
    substituters = [
      "https://cache.nixos.org"
      "https://cache.garnix.io"
      "https://nix-community.cachix.org"
    ];
    trusted-public-keys = [
      "cache.nixos.org-1:6NCHdD59X431o0gWypbMrAURkbJ16ZPMQFGspcDShjY="
      "cache.garnix.io:CTFPyKSLcx5RMJKfLo5EEPUObbA78b0YQ2DTCJXqr9g="
      "nix-community.cachix.org-1:mB9FSh9qf2dCimDSUo8Zy7bkq5CX+/rkCWyvRCYg3Fs="
    ];

    # If a cache is down, build instead of hanging.
    connect-timeout = 5;
    fallback = true;
  };

  nix.gc = {
    automatic = true;
    dates = "weekly";
    options = "--delete-older-than 14d";
  };

  # Never change this after install, even on upgrades.
  system.stateVersion = "26.05";
}
