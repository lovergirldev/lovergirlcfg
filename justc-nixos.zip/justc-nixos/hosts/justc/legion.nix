{ config, pkgs, ... }:

{
  # ---------- Legion Toolkit replacement stack ----------

  # Power modes (quiet/balanced/performance). Fn+Q also works at firmware
  # level; this exposes the same platform profiles to the OS + waybar/Plasma.
  services.power-profiles-daemon.enable = true;

  # Battery conservation mode (cap charge ~60-80% for longevity).
  # Usage:  conserve on | conserve off | conserve      (status)
  environment.systemPackages = with pkgs; [
    (writeShellScriptBin "conserve" ''
      SYS=/sys/bus/platform/drivers/ideapad_acpi/VPC2004:00/conservation_mode
      if [ ! -e "$SYS" ]; then
        echo "conservation_mode node not found (ideapad_laptop module not bound?)"
        exit 1
      fi
      case "$1" in
        on)  echo 1 | sudo tee "$SYS" >/dev/null && echo "conservation: ON (charge capped)";;
        off) echo 0 | sudo tee "$SYS" >/dev/null && echo "conservation: OFF (full charge)";;
        *)   echo "conservation: $(cat "$SYS")  (1=on, 0=off)";;
      esac
    '')
  ];

  # ---------- Experimental (attempt, no promises) ----------

  # Fingerprint reader — sensor support is device-lottery on this model.
  # Test with: fprintd-enroll   (if it errors, just leave this on or remove it;
  # PAM falls back to password either way).
  services.fprintd.enable = true;

  # Per-key RGB via OpenRGB. Detection is model-dependent; if OpenRGB doesn't
  # see the keyboard, Fn+Space firmware control always works.
  services.hardware.openrgb.enable = true;

  # LenovoLegionLinux (fan curves etc.) — support for the Slim 7 16IRH8 is
  # partial upstream and the out-of-tree module can lag the latest kernel.
  # SHIPPED DISABLED so it can never break your rebuilds. To experiment,
  # uncomment all three lines and rebuild; if the build fails, re-comment.
  # boot.extraModulePackages = [ config.boot.kernelPackages.lenovo-legion-module ];
  # boot.kernelModules = [ "legion_laptop" ];
  # environment.systemPackages = [ pkgs.lenovo-legion ];
}
