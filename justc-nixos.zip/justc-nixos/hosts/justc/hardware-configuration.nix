# ============================ STUB — REPLACE ME ============================
# On install day (README step 6), generate the real file on the machine:
#
#   sudo nixos-generate-config --no-filesystems --root /mnt
#   cp /mnt/etc/nixos/hardware-configuration.nix hosts/justc/hardware-configuration.nix
#
# (--no-filesystems because disko.nix already declares the filesystems.)
# The generated file contains the initrd kernel modules for YOUR nvme/usb
# controllers — the system will not boot without it.
# ===========================================================================
{ ... }:
{
  # intentionally empty until replaced
}
