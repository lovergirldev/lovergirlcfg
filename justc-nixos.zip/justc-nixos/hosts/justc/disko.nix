# Declarative disk layout — used ONCE on install day by disko, then it also
# provides the fileSystems/luks entries for the running system.
#
# !!! CHANGEME #1: set `device` to your NixOS target SSD (the one WITHOUT
# Windows). Verify with:  lsblk -o NAME,SIZE,MODEL   — Windows disk will show
# an ~100MB "EFI"/ntfs layout. Getting this wrong ERASES the wrong drive.
{
  disko.devices.disk.main = {
    type = "disk";
    device = "/dev/nvme0n1";   # CHANGEME #1
    content = {
      type = "gpt";
      partitions = {
        esp = {
          size = "1G";
          type = "EF00";
          content = {
            type = "filesystem";
            format = "vfat";
            mountpoint = "/boot";
            mountOptions = [ "umask=0077" ];
          };
        };
        luks = {
          size = "100%";
          content = {
            type = "luks";
            name = "cryptroot";
            # Install-day only: disko reads the passphrase from this file
            # (README step 3 creates it on the live ISO's tmpfs).
            passwordFile = "/tmp/luks.pass";
            settings.allowDiscards = true;
            content = {
              type = "btrfs";
              extraArgs = [ "-f" ];
              subvolumes = {
                "@" = {
                  mountpoint = "/";
                  mountOptions = [ "compress=zstd" "noatime" ];
                };
                "@home" = {
                  mountpoint = "/home";
                  mountOptions = [ "compress=zstd" "noatime" ];
                };
                "@nix" = {
                  mountpoint = "/nix";
                  mountOptions = [ "compress=zstd" "noatime" ];
                };
                "@snapshots" = {
                  mountpoint = "/.snapshots";
                  mountOptions = [ "compress=zstd" "noatime" ];
                };
              };
            };
          };
        };
      };
    };
  };
}
