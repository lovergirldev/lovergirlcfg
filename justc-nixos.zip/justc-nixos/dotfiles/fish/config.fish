set -g fish_greeting ""

if status is-interactive
    starship init fish | source
end

# ---- NixOS ----
alias nrs "sudo nixos-rebuild switch --flake ~/nixos#justc"   # rebuild
alias nup "cd ~/nixos; and nix flake update; and nrs"          # update everything
alias ngc "sudo nix-collect-garbage --delete-older-than 14d"   # reclaim space

# ---- VPN toggles (never connect both at once) ----
alias warp-on  "warp-cli connect"
alias warp-off "warp-cli disconnect"
# mullvad: use the GUI, or `mullvad connect` / `mullvad disconnect`
# the waybar VPN widget enforces the one-at-a-time rule for you

# `conserve on|off` (battery charge cap) is a system script — see legion.nix

# ---- Flatpak ----
# The Flathub remote is added automatically on first boot.
alias fpi "flatpak install flathub"
alias fps "flatpak search"
alias fpu "flatpak update"
alias fpl "flatpak list --app"

# ---- fetch ----
# neofetch is archived upstream; fastfetch is the maintained successor and
# reads ~/.config/fastfetch/config.jsonc (nix logo, trans flag colours).
alias neofetch "fastfetch"
alias ff "fastfetch"

# ---- editors ----
# `nvim` = plain Neovim, your own ~/.config/nvim (untouched).
# `nvix` = the declarative nixvim build — see modules/nixvim.nix.

# ---- files / theming helpers ----
alias y "yazi"
alias dots "cp ~/.config/niri/config.kdl ~/nixos/dotfiles/niri/config.kdl; cp -r ~/.config/waybar/* ~/nixos/dotfiles/waybar/; cp ~/.config/ghostty/config ~/nixos/dotfiles/ghostty/config; cp -r ~/.config/fastfetch/* ~/nixos/dotfiles/fastfetch/; echo 'dotfiles copied back to ~/nixos'"
alias bar "killall -SIGUSR2 waybar"          # reload waybar after a CSS edit
alias ew "eww reload"                        # reload applets after an scss edit
alias ewr "eww kill; and eww daemon"         # hard restart if eww gets stuck
alias theme-list "ls /run/current-system/sw/share/themes /run/current-system/sw/share/icons"
# plasma-oxygen  — re-apply Oxygen Dark in the KDE session (runs itself once at
#                  first login; safe to run again any time)
# claude-marketplaces — add the Claude Code plugin marketplaces (needs network)

# ---- boot ----
# Limine is the bootloader. Inspect its generated menu with:
alias bootcfg "sudo cat /boot/limine.conf"
alias espfree "df -h /boot"                   # ESP is 1G; 8 generations fit
