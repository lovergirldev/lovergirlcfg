#!/usr/bin/env bash
## Launcher — type-7 / style-1
dir="$HOME/.config/rofi/launchers/type-7"
theme='style-1'

rofi -show drun -theme "${dir}/${theme}.rasi"
