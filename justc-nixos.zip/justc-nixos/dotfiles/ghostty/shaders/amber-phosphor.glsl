// amber-phosphor.glsl — justc
// A restrained CRT for ghostty. Shadertoy-style entry point; iChannel0 is
// the terminal's rendered content.
//
// Tuned so text stays LEGIBLE (your first design rule). Scanlines are faint,
// the bloom only lifts warm pixels so the amber accent glows and the ink
// stays ink, and the curvature is almost nothing — just enough to read as
// glass rather than as a gimmick.
//
// Turn knobs down to zero to disable any single effect.

const float SCANLINE_DEPTH = 0.055;   // 0.0 = off,  0.15 = heavy
const float BLOOM_AMOUNT   = 0.34;    // warm glow strength
const float VIGNETTE       = 0.22;    // corner falloff
const float CURVE          = 0.014;   // barrel distortion
const float ABERRATION     = 0.0007;  // rgb split at the edges
const float FLICKER        = 0.008;   // mains hum

vec2 curveUV(vec2 uv) {
    uv = uv * 2.0 - 1.0;
    vec2 offset = abs(uv.yx) / vec2(6.0, 5.0);
    uv += uv * offset * offset * CURVE * 12.0;
    return uv * 0.5 + 0.5;
}

void mainImage(out vec4 fragColor, in vec2 fragCoord) {
    vec2 uv = fragCoord / iResolution.xy;
    vec2 cuv = curveUV(uv);

    // outside the tube
    if (cuv.x < 0.0 || cuv.x > 1.0 || cuv.y < 0.0 || cuv.y > 1.0) {
        fragColor = vec4(0.043, 0.051, 0.067, 1.0);   // #0b0d11
        return;
    }

    // chromatic aberration, strongest at the edges
    vec2 fromCenter = cuv - 0.5;
    float edge = dot(fromCenter, fromCenter);
    vec3 col;
    col.r = texture(iChannel0, cuv + fromCenter * ABERRATION * edge * 40.0).r;
    col.g = texture(iChannel0, cuv).g;
    col.b = texture(iChannel0, cuv - fromCenter * ABERRATION * edge * 40.0).b;

    // warm bloom: sample a small cross, keep only what is already warm
    vec3 blur = vec3(0.0);
    float px = 1.5 / iResolution.y;
    blur += texture(iChannel0, cuv + vec2(0.0,  px)).rgb;
    blur += texture(iChannel0, cuv + vec2(0.0, -px)).rgb;
    blur += texture(iChannel0, cuv + vec2( px, 0.0)).rgb;
    blur += texture(iChannel0, cuv + vec2(-px, 0.0)).rgb;
    blur *= 0.25;
    float warmth = clamp(blur.r - blur.b, 0.0, 1.0);
    col += blur * warmth * BLOOM_AMOUNT;

    // scanlines
    float scan = sin(cuv.y * iResolution.y * 3.14159) * 0.5 + 0.5;
    col *= 1.0 - SCANLINE_DEPTH * scan;

    // aperture grille — very subtle vertical triad
    float grille = sin(fragCoord.x * 3.14159 * 0.5) * 0.5 + 0.5;
    col *= 1.0 - 0.018 * grille;

    // mains flicker
    col *= 1.0 - FLICKER * sin(iTime * 60.0);

    // vignette
    col *= 1.0 - VIGNETTE * edge * 2.2;

    fragColor = vec4(col, 1.0);
}
