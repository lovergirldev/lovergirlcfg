#!/usr/bin/env bash
# waybar custom/vpn — one indicator for BOTH tunnels, because the house rule
# is that only one may be CONNECTED at a time. Left click toggles Mullvad,
# right click toggles WARP; each refuses if the other is already up.

mullvad_up() { mullvad status 2>/dev/null | grep -qi 'connected' && ! mullvad status 2>/dev/null | grep -qi 'disconnected'; }
warp_up()    { warp-cli --accept-tos status 2>/dev/null | grep -qi 'connected' && ! warp-cli --accept-tos status 2>/dev/null | grep -qi 'disconnected'; }

case "${1:-}" in
  toggle-mullvad)
    if mullvad_up; then mullvad disconnect >/dev/null 2>&1
    elif warp_up; then notify-send "VPN" "Disconnect WARP first — never both at once."
    else mullvad connect >/dev/null 2>&1; fi
    exit 0 ;;
  toggle-warp)
    if warp_up; then warp-cli --accept-tos disconnect >/dev/null 2>&1
    elif mullvad_up; then notify-send "VPN" "Disconnect Mullvad first — never both at once."
    else warp-cli --accept-tos connect >/dev/null 2>&1; fi
    exit 0 ;;
esac

if mullvad_up && warp_up; then
  printf '{"text":"󰦝 BOTH","tooltip":"Mullvad AND WARP are both connected — they fight over routing. Turn one off.","class":"conflict"}\n'
elif mullvad_up; then
  loc=$(mullvad status 2>/dev/null | head -1 | tr -d '"' | cut -c1-40)
  printf '{"text":"󰦝 mullvad","tooltip":"%s","class":"mullvad"}\n' "${loc:-Mullvad connected}"
elif warp_up; then
  printf '{"text":"󰦝 warp","tooltip":"Cloudflare WARP connected","class":"warp"}\n'
else
  printf '{"text":"󰦞","tooltip":"No VPN — left click Mullvad, right click WARP","class":"off"}\n'
fi
