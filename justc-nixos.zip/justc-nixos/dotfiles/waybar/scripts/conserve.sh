#!/usr/bin/env bash
# waybar custom/conserve — Legion battery conservation mode (charge cap).
# Surfaces the same sysfs node the `conserve` command uses.
SYS=/sys/bus/platform/drivers/ideapad_acpi/VPC2004:00/conservation_mode

[ -e "$SYS" ] || { printf '{"text":"","tooltip":"conservation_mode node not present"}\n'; exit 0; }

if [ "${1:-}" = "toggle" ]; then
  if [ "$(cat "$SYS")" = "1" ]; then conserve off >/dev/null 2>&1
  else conserve on >/dev/null 2>&1; fi
  exit 0
fi

if [ "$(cat "$SYS")" = "1" ]; then
  printf '{"text":"󰢞","tooltip":"charge capped (conservation ON) — click to disable","class":"on"}\n'
else
  printf '{"text":"","tooltip":"charging to 100%% — click to cap","class":"off"}\n'
fi
