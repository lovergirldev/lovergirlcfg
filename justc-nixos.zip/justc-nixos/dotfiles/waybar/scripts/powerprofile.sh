#!/usr/bin/env bash
# waybar custom/powerprofile — reads power-profiles-daemon. Click cycles.
have() { command -v powerprofilesctl >/dev/null 2>&1; }
have || { printf '{"text":"","tooltip":"power-profiles-daemon not running"}\n'; exit 0; }

if [ "${1:-}" = "next" ]; then
  cur=$(powerprofilesctl get 2>/dev/null)
  case "$cur" in
    power-saver)  powerprofilesctl set balanced    2>/dev/null ;;
    balanced)     powerprofilesctl set performance 2>/dev/null ;;
    *)            powerprofilesctl set power-saver 2>/dev/null ;;
  esac
  exit 0
fi

cur=$(powerprofilesctl get 2>/dev/null)
case "$cur" in
  power-saver)  printf '{"text":"󰌪 quiet","tooltip":"power-saver — click to cycle","class":"saver"}\n' ;;
  balanced)     printf '{"text":"󰾅 balanced","tooltip":"balanced — click to cycle","class":"balanced"}\n' ;;
  performance)  printf '{"text":"󰓅 perf","tooltip":"performance — click to cycle","class":"performance"}\n' ;;
  *)            printf '{"text":"󰾅","tooltip":"%s","class":"balanced"}\n' "${cur:-unknown}" ;;
esac
