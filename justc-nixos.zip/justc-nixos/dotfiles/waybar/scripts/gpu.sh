#!/usr/bin/env bash
# waybar custom/gpu — RTX 4070 Laptop utilisation / temp / VRAM.
# Outputs waybar JSON. Silent no-op if nvidia-smi is missing.
read -r util temp used total < <(
  nvidia-smi --query-gpu=utilization.gpu,temperature.gpu,memory.used,memory.total \
             --format=csv,noheader,nounits 2>/dev/null | tr -d ',' 
) || true

if [ -z "${util:-}" ]; then
  printf '{"text":"","tooltip":"nvidia-smi unavailable"}\n'
  exit 0
fi

cls="ok"
[ "$temp" -ge 75 ] 2>/dev/null && cls="warm"
[ "$temp" -ge 85 ] 2>/dev/null && cls="hot"

printf '{"text":"󰢮 %s%%","tooltip":"GPU %s%%  ·  %s°C  ·  VRAM %s / %s MiB","class":"%s"}\n' \
  "$util" "$util" "$temp" "$used" "$total" "$cls"
