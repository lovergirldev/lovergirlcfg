#!/usr/bin/env bash
# Copies these dotfiles into ~/.config as REAL FILES (deliberate: no symlinks,
# so nothing dangles if ~/nixos moves). Existing files are backed up as *.bak
# once. Safe to re-run any time — this is the "my theming broke, reset it" button.
set -euo pipefail

DOTS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CFG="$HOME/.config"

copy() { # copy <repo-path> <target-path>
  local src="$DOTS/$1" dst="$2"
  mkdir -p "$(dirname "$dst")"
  if [ -e "$dst" ] && [ ! -L "$dst" ] && [ ! -e "$dst.bak" ]; then cp -r "$dst" "$dst.bak"; fi
  rm -rf "$dst"
  cp -r "$src" "$dst"
  echo "copied  $dst"
}

copy niri/config.kdl        "$CFG/niri/config.kdl"
copy waybar/config.jsonc    "$CFG/waybar/config.jsonc"
copy waybar/style.css       "$CFG/waybar/style.css"
copy waybar/scripts         "$CFG/waybar/scripts"
copy ghostty/config         "$CFG/ghostty/config"
copy ghostty/shaders        "$CFG/ghostty/shaders"
copy ghostty/backgrounds    "$CFG/ghostty/backgrounds"
copy fastfetch              "$CFG/fastfetch"
copy eww                    "$CFG/eww"
copy fish/config.fish       "$CFG/fish/config.fish"
copy starship.toml          "$CFG/starship.toml"
copy rofi                   "$CFG/rofi"
copy hypr/hyprlock.conf     "$CFG/hypr/hyprlock.conf"
copy hypr/hypridle.conf     "$CFG/hypr/hypridle.conf"
copy swaync/config.json     "$CFG/swaync/config.json"
copy swaync/style.css       "$CFG/swaync/style.css"
copy yazi/yazi.toml         "$CFG/yazi/yazi.toml"
copy yazi/theme.toml        "$CFG/yazi/theme.toml"

# NOTE: gtk-3.0 / gtk-4.0 settings.ini are deliberately NOT copied here any
# more. theme-apply owns the theme-name keys in those files and merges into
# whatever else is present, so shipping a competing copy just caused the two
# to fight (old bug 3). Run `theme-apply` to regenerate them.

chmod +x "$CFG"/rofi/launchers/*/*.sh "$CFG"/rofi/powermenu/*/*.sh \
         "$CFG"/rofi/applets/bin/*.sh "$CFG"/waybar/scripts/*.sh "$CFG"/eww/scripts/*.sh 2>/dev/null || true
mkdir -p "$HOME/Pictures/Screenshots"

echo
echo "done. In niri, everything but GTK reloads on save; log out/in for the rest."
