#!/usr/bin/env bash
# eww power applet data + actions
BAT="$(ls -d /sys/class/power_supply/BAT* 2>/dev/null | head -1)"
SYS=/sys/bus/platform/drivers/ideapad_acpi/VPC2004:00/conservation_mode

case "${1:-cap}" in
  cap)     v=$(cat "$BAT/capacity" 2>/dev/null); echo "${v:-0}" ;;
  status)  v=$(cat "$BAT/status" 2>/dev/null | tr '[:upper:]' '[:lower:]'); echo "${v:-unknown}" ;;
  profile) powerprofilesctl get 2>/dev/null || echo balanced ;;
  conserve) [ "$(cat "$SYS" 2>/dev/null)" = "1" ] && echo yes || echo no ;;
  conserve-toggle)
    if [ "$(cat "$SYS" 2>/dev/null)" = "1" ]; then conserve off; else conserve on; fi
    ;;
  timeleft)
    t=$(acpi -b 2>/dev/null | grep -oE '[0-9]{2}:[0-9]{2}:[0-9]{2}' | head -1)
    if [ -n "$t" ]; then
      echo "${t%:*} remaining"
    else
      echo ""
    fi
    ;;
esac
