#!/usr/bin/env bash
# eww screenshot applet — the applet must be gone BEFORE the shot is taken,
# which is the one thing the rofi version got for free by exiting first.
eww close-all
sleep 0.25
case "${1:-region}" in
  region) niri msg action screenshot ;;
  screen) niri msg action screenshot-screen ;;
  window) niri msg action screenshot-window ;;
  delay)  sleep 3; niri msg action screenshot ;;
  folder) setsid ghostty -e yazi "$HOME/Pictures/Screenshots" >/dev/null 2>&1 & ;;
esac
