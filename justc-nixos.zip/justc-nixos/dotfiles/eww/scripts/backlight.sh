#!/usr/bin/env bash
# eww brightness applet data + actions
case "${1:-get}" in
  get)   v=$(brightnessctl -m 2>/dev/null | awk -F, '{gsub("%","",$4); print $4}'); echo "${v:-50}" ;;
  set)   brightnessctl set "${2:-50}%" >/dev/null 2>&1 ;;
  night) pgrep -x wlsunset >/dev/null 2>&1 && echo on || echo off ;;
  night-toggle)
    if pgrep -x wlsunset >/dev/null 2>&1; then
      pkill -x wlsunset
    else
      setsid wlsunset -t 4000 -T 6500 >/dev/null 2>&1 &
    fi
    ;;
esac
