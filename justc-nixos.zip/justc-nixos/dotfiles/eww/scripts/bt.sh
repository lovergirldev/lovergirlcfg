#!/usr/bin/env bash
# eww bluetooth applet data + actions
case "${1:-power}" in
  power)
    [ "$(bluetoothctl show 2>/dev/null | awk '/Powered:/{print $2}')" = "yes" ] && echo on || echo off ;;
  toggle)
    if [ "$(bluetoothctl show 2>/dev/null | awk '/Powered:/{print $2}')" = "yes" ]; then
      bluetoothctl power off
    else
      bluetoothctl power on
    fi
    ;;
  devices)
    # JSON array for eww's (for d in bt-list)
    first=1
    printf '['
    while read -r _ mac name; do
      [ -n "$mac" ] || continue
      if bluetoothctl info "$mac" 2>/dev/null | grep -q 'Connected: yes'; then c=yes; else c=no; fi
      esc=$(printf '%s' "$name" | sed 's/\\/\\\\/g; s/"/\\"/g')
      [ $first -eq 1 ] || printf ','
      printf '{"mac":"%s","name":"%s","connected":"%s"}' "$mac" "$esc" "$c"
      first=0
    done < <(bluetoothctl devices Paired 2>/dev/null)
    printf ']\n'
    ;;
  connect)
    mac="${2:-}"
    [ -n "$mac" ] || exit 0
    if bluetoothctl info "$mac" 2>/dev/null | grep -q 'Connected: yes'; then
      bluetoothctl disconnect "$mac"
    else
      bluetoothctl connect "$mac"
    fi
    ;;
  scan) setsid blueman-manager >/dev/null 2>&1 & eww close-all ;;
esac
