#!/usr/bin/env bash
# eww quicklinks — open a URL in Helium, then dismiss the applet
b=helium
command -v "$b" >/dev/null 2>&1 || b=xdg-open
setsid "$b" "$1" >/dev/null 2>&1 &
eww close-all
