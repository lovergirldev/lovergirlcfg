#!/usr/bin/env bash
# eww volume applet data + actions
SINK="@DEFAULT_AUDIO_SINK@"
SRC="@DEFAULT_AUDIO_SOURCE@"

case "${1:-vol}" in
  vol)       v=$(wpctl get-volume "$SINK" 2>/dev/null | awk '{printf "%d", $2*100}'); echo "${v:-0}" ;;
  muted)     wpctl get-volume "$SINK" 2>/dev/null | grep -q MUTED && echo yes || echo no ;;
  mic)       v=$(wpctl get-volume "$SRC"  2>/dev/null | awk '{printf "%d", $2*100}'); echo "${v:-0}" ;;
  mic-muted) wpctl get-volume "$SRC"  2>/dev/null | grep -q MUTED && echo yes || echo no ;;

  set-vol)   wpctl set-volume -l 1.0 "$SINK" "${2:-50}%" ;;
  set-mic)   wpctl set-volume -l 1.0 "$SRC"  "${2:-50}%" ;;
  toggle-mute) wpctl set-mute "$SINK" toggle ;;
  toggle-mic)  wpctl set-mute "$SRC"  toggle ;;

  cycle-sink)
    # move the default to the next sink in the list, and drag streams with it
    ids=$(wpctl status | sed -n '/Sinks:/,/Sources:/p' | grep -oE '[0-9]+\.' | tr -d '.')
    cur=$(wpctl status | sed -n '/Sinks:/,/Sources:/p' | grep '\*' | grep -oE '[0-9]+\.' | tr -d '.')
    next=$(echo "$ids" | awk -v c="$cur" 'BEGIN{f=0} {a[NR]=$0} END{for(i=1;i<=NR;i++) if(a[i]==c){print a[(i%NR)+1]; f=1}; if(!f) print a[1]}')
    [ -n "$next" ] && wpctl set-default "$next"
    ;;
esac
