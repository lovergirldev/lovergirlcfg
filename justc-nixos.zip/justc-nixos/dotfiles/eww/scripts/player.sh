#!/usr/bin/env bash
# eww media applet data
case "${1:-status}" in
  status) playerctl status 2>/dev/null || echo Stopped ;;
  artist) playerctl metadata --format '{{artist}}' 2>/dev/null || echo "" ;;
  title)
    t=$(playerctl metadata --format '{{title}}' 2>/dev/null)
    [ -n "$t" ] && echo "$t" || echo "nothing playing"
    ;;
  art)
    url=$(playerctl metadata --format '{{mpris:artUrl}}' 2>/dev/null)
    case "$url" in
      file://*) echo "${url}" ;;
      http*)
        cache="$HOME/.cache/eww-art"
        mkdir -p "$cache"
        f="$cache/$(echo "$url" | md5sum | cut -c1-16)"
        [ -f "$f" ] || curl -sfL --max-time 4 "$url" -o "$f" 2>/dev/null
        [ -s "$f" ] && echo "file://$f" || echo ""
        ;;
      *) echo "" ;;
    esac
    ;;
esac
