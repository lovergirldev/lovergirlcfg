#!/usr/bin/env bash
# Single entry point for the keybinds and the waybar clicks.
#   applet.sh volume | brightness | battery | bluetooth | media | quicklinks | screenshot
#
# Opening one closes the others, so you can never stack two applets — same
# behaviour the rofi versions had by virtue of being modal.
set -u
W="${1:-}"
[ -n "$W" ] || { echo "usage: applet.sh <window>"; exit 1; }

# make sure the daemon is up (niri starts it, but this makes the binds
# self-healing if it ever dies)
eww ping >/dev/null 2>&1 || eww daemon >/dev/null 2>&1

if eww active-windows 2>/dev/null | grep -q "^$W"; then
  eww close "$W"
else
  eww close-all 2>/dev/null
  eww open "$W"
fi
