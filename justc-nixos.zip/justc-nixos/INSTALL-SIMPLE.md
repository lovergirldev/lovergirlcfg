# Simple install guide — justc

The short version. No Git, no USB key on day one — just get the files on the
laptop, encrypt with a passphrase, install. (The optional USB unlock key is at
the bottom, for whenever you feel like it.)

Some of this is unavoidably technical — encrypting a disk just is. But every
command below is copy-paste. Take it one step at a time.

---

## Before you start

Have these three things ready:

1. **A NixOS installer USB.** On your current computer, download the NixOS
   **graphical** ISO from nixos.org, and write it to a USB stick with Ventoy or
   Rufus.
2. **The config folder on a second USB stick.** Unzip `justc-nixos.zip` on your
   current computer, then copy the resulting `justc-nixos` folder onto any spare
   USB stick. (Or, since you use Filen: upload the folder there instead — you'll
   download it inside the installer.)
3. **A passphrase you'll remember.** You'll type this every time the laptop
   boots, before login. Make it strong but memorable. If you forget it, the
   drive is unrecoverable — that's the point of encryption.

Windows on your other SSD is not touched. Secure Boot is already off, so there's
nothing to change in the BIOS.

---

## The install

**1. Boot the installer.**
Plug in the NixOS installer USB, power on, tap **F12**, pick the USB. You land on
a desktop. Connect Wi-Fi from the icon in the bottom-right.

**2. Get the config folder onto the laptop.**
Plug in your second USB stick (or open Filen in the browser). Open the **Files**
app, copy the `justc-nixos` folder into **Home**, and rename it to `nixos` so the
path is `~/nixos`. (Renaming is optional — it just makes the commands shorter.)

**3. Open the terminal** (Konsole, in the app menu) and turn on flakes for this
session:

```bash
export NIX_CONFIG="experimental-features = nix-command flakes"
```

**4. Find your target disk:**

```bash
lsblk -o NAME,SIZE,MODEL,FSTYPE
```

You'll see two NVMe disks. The one showing `ntfs` partitions is **Windows —
leave it alone**. The other one is your target. Note its name (like
`nvme0n1` or `nvme1n1`).

**5. Point the config at that disk.**
Open the file manager, go to `~/nixos/hosts/justc/`, right-click
`disko.nix` → open with a text editor. Find this line near the top:

```
    device = "/dev/nvme0n1";   # CHANGEME #1
```

Change it to your target disk's name (keep the `/dev/` part), save, close.

**6. Encrypt, format, and mount — one block.**
Replace the passphrase text with yours, then paste all three lines:

```bash
echo -n 'type-your-passphrase-here' > /tmp/luks.pass
sudo -E nix run github:nix-community/disko/latest -- \
  --mode destroy,format,mount --flake ~/nixos#justc
```

⚠️ This erases the target disk. When it finishes, run `findmnt /mnt` — you
should see it's mounted. If you do, you're past the scary part.

**7. Add your hardware's details to the config:**

```bash
sudo nixos-generate-config --no-filesystems --root /mnt
cp /mnt/etc/nixos/hardware-configuration.nix ~/nixos/hosts/justc/hardware-configuration.nix
```

**8. Install:**

```bash
sudo -E nixos-install --flake ~/nixos#justc
```

This takes a while — it's downloading the NVIDIA driver, KDE, DaVinci Resolve,
and more. Grab a coffee. At the very end it asks you to set a **root password** —
do that.

(Don't worry about Git — because `~/nixos` is a plain folder, the installer just
uses everything in it.)

**9. Reboot into your new system:**

```bash
sudo reboot
```

Remove the installer USB when the screen goes black. On startup you'll be asked
for your **LUKS passphrase** (from step 6), then you reach the login screen. Log
in as `lovergirlonline` with password `changeme`, open a terminal, and set your
real password right away:

```bash
passwd
```

**That's a working system.** Everything below is optional polish.

---

## Right after install (5 minutes)

**Turn on your dotfiles and the niri desktop:**

```bash
bash ~/nixos/dotfiles/link.sh
```

Log out (or press **Super+Shift+E**), and at the login screen make sure the
session says **niri** before logging back in. Press **Super+Shift+/** anytime to
see the keyboard shortcuts. Super+T opens a terminal, Super+D opens the app
launcher.

**Sign into your apps** at your own pace: Mullvad, Steam, Filen, Bitwarden,
Affinity (first launch is slow — it's setting itself up), DaVinci Resolve
(enter your license). Full per-app notes are in `README.md` step 12.

**Add the Windows boot entry** (so you can pick Windows from the boot menu
instead of tapping F12): this one needs the UEFI-shell trick — it's spelled out
in `README.md` step 10. Until then, **F12 at startup → Windows Boot Manager**
works fine.

---

## Adding your USB unlock key (optional, anytime)

This lets the laptop unlock automatically when a specific USB stick is plugged
in, and fall back to the passphrase when it isn't. Do this on the running
system whenever you want — no rush.

**1. Plug in the stick you want to use as the key. Find its ID:**

```bash
ls -l /dev/disk/by-id/ | grep -i usb
```

Note the name that starts with `usb-` (not the one ending in `-part1`).

**2. Write a random key onto it and enroll it:**

```bash
KEY=/dev/disk/by-id/usb-XXXX          # paste yours
sudo dd if=/dev/urandom of=$KEY bs=4096 seek=2560 count=1 conv=fsync
sudo cryptsetup luksAddKey /dev/nvme0n1p2 $KEY \
  --new-keyfile-offset 10485760 --new-keyfile-size 4096
```

Replace `/dev/nvme0n1p2` with **partition 2 of your target disk** (e.g.
`nvme1n1p2`). It'll ask for your passphrase to authorize.

**3. Turn on key-unlocking in the config.**
Edit `~/nixos/hosts/justc/boot.nix`, find the commented `boot.initrd.luks`
block, uncomment it, and set `keyFile` to your `usb-XXXX` path. Then:

```bash
sudo nixos-rebuild switch --flake ~/nixos#justc
```

Reboot with the stick in — it should unlock on its own. Pull the stick and
reboot once more to confirm the passphrase still works as backup.

**Keep a backup:** copy the same key bytes onto a second stick (details in
`README.md`), and remember the passphrase is always your recovery path.

---

## The two commands you'll actually use

```bash
nrs    # rebuild after you edit anything in ~/nixos
nup    # update everything to the latest
```

If an update ever breaks something, reboot and pick the previous entry in the
boot menu — you're instantly back to how it was.
