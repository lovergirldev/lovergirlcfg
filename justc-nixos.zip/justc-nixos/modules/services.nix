{ config, pkgs, ... }:

{
  # ---------- Audio: PipeWire ----------
  security.rtkit.enable = true;
  services.pipewire = {
    enable = true;
    alsa.enable = true;
    alsa.support32Bit = true;   # game audio via Proton
    pulse.enable = true;
  };

  # ---------- Bluetooth ----------
  hardware.bluetooth = {
    enable = true;
    powerOnBoot = true;
  };

  # BUGFIX 2: blueman was installed as a package but its D-Bus service was
  # never enabled, so waybar's bluetooth module opened blueman-manager and it
  # could not actually pair or configure anything. This is the missing half.
  services.blueman.enable = true;

  # ---------- Flatpak ----------
  # Flathub is NOT added automatically. First boot, run once:
  #   flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo
  # (the `flathub-setup` service below does this for you on first boot)
  services.flatpak.enable = true;

  systemd.services.flathub-setup = {
    description = "Add the Flathub remote once";
    wantedBy = [ "multi-user.target" ];
    after = [ "network-online.target" "flatpak-system-helper.service" ];
    wants = [ "network-online.target" ];
    serviceConfig = {
      Type = "oneshot";
      RemainAfterExit = true;
    };
    script = ''
      ${pkgs.flatpak}/bin/flatpak remote-add --if-not-exists \
        flathub https://flathub.org/repo/flathub.flatpakrepo || true
    '';
  };

  # ---------- Removable media, trash, network shares ----------
  # BUGFIX 5: without these a USB stick does not auto-mount, and Trash /
  # smb:// / mtp:// are dead in yazi, Dolphin and every GTK file dialog.
  services.udisks2.enable = true;
  services.gvfs.enable = true;
  services.tumbler.enable = true;   # thumbnails for GTK file dialogs

  # ---------- Firmware updates (component a) ----------
  # Lenovo publishes Legion BIOS/EC updates to LVFS. Check with:
  #   fwupdmgr refresh && fwupdmgr get-updates && fwupdmgr update
  services.fwupd.enable = true;

  # ---------- Intel thermal management (component e) ----------
  # 13th-gen HX in a slim chassis; thermald keeps it off the thermal wall
  # more gracefully than the kernel's default throttling.
  services.thermald.enable = true;

  # ---------- Printing (+ network printer discovery) ----------
  services.printing.enable = true;
  services.avahi = {
    enable = true;
    nssmdns4 = true;
    openFirewall = true;
  };

  # ---------- SSD + Btrfs upkeep ----------
  services.fstrim.enable = true;
  services.btrfs.autoScrub = {
    enable = true;
    interval = "monthly";
    fileSystems = [ "/" ];
  };

  # ---------- /home snapshots ----------
  services.snapper.configs.home = {
    SUBVOLUME = "/home";
    ALLOW_USERS = [ "lovergirlonline" ];
    TIMELINE_CREATE = true;
    TIMELINE_CLEANUP = true;
    TIMELINE_LIMIT_HOURLY = 5;
    TIMELINE_LIMIT_DAILY = 7;
    TIMELINE_LIMIT_WEEKLY = 3;
    TIMELINE_LIMIT_MONTHLY = 2;
    TIMELINE_LIMIT_YEARLY = 0;
  };
}
