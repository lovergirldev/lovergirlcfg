{ config, lib, pkgs, inputs, havePkgs, missingPkgs, ... }:

let
  # Plain nixpkgs attribute names, looked up by string via modules/guard.nix so
  # a rename upstream drops the package instead of aborting the whole install.
  # Anything that is NOT a plain nixpkgs name (flake inputs, overrides) stays
  # out of this list and is added literally below.
  wanted = [
    # ---------- Creative ----------
    # BUGFIX 1a: this is pkgs.affinity-v3, provided by affinity-nix's own
    # overlay (see hosts/justc/default.nix) rather than a direct
    # inputs.<>.packages reference. Their README calls the overlay the
    # recommended path precisely because the package is unfree.
    "affinity-v3"
    "davinci-resolve-studio"
    "godot_4-mono"
    "vscodium"
    "anytype"

    # ---------- Essentials ----------
    "filen-desktop"
    "bitwarden-desktop"
    "bottles"
    "thunderbird"
    "discord"                  # official client; Wayland screenshare + audio works
    "signal-desktop"           # GUI Signal
    "neovim"                   # plain nvim, your own ~/.config/nvim
    "helix"
    "github-desktop"

    # ---------- Package management GUIs ----------
    "kdePackages.discover"     # Flatpak + firmware front-end (pairs with fwupd)

    # ---------- Media ----------
    "haruna"
    "vlc"
    "qimgv"

    # ---------- Monitoring ----------
    "btop"
    "nvtopPackages.nvidia"

    # ---------- Archive ----------
    "kdePackages.ark"
    "p7zip"
    "unzip"
    "unrar"

    # ---------- Basics ----------
    "git"
    "curl"
    "fastfetch"                # replaces neofetch (archived upstream)
  ];
in
{
  justc.missingPackages = missingPkgs wanted;

  environment.systemPackages =
    [
      # ---------- Browser ----------
      inputs.helium.packages.${pkgs.system}.default

      # nix-software-center: browse/install nixpkgs like a store (vlinkz).
      # A flake input, so it is not guarded — if this ever fails, try
      # `.nix-software-center` instead of `.default`.
      inputs.nix-software-center.packages.${pkgs.system}.default
    ]
    ++ havePkgs wanted;

  # LACT — GPU monitoring/clocks/power-limit.
  services.lact.enable = true;
}
