{ config, pkgs, inputs, ... }:

{
  environment.systemPackages = with pkgs; [
    # ---------- Browser ----------
    inputs.helium.packages.${pkgs.system}.default

    # ---------- Creative ----------
    # BUGFIX 1a: this is now pkgs.affinity-v3, provided by affinity-nix's own
    # overlay (see hosts/justc/default.nix) instead of a direct
    # inputs.<>.packages reference. Their README calls the overlay the
    # recommended path precisely because the package is unfree.
    affinity-v3
    davinci-resolve-studio
    godot_4-mono
    vscodium
    anytype

    # ---------- Essentials ----------
    filen-desktop
    bitwarden-desktop
    bottles
    thunderbird
    discord                  # official client; Wayland screenshare + audio works
    signal-desktop           # NEW — GUI Signal
    neovim                   # plain nvim, your own ~/.config/nvim
    helix
    github-desktop

    # ---------- Package management GUIs ----------
    # nix-software-center: browse/install nixpkgs like a store (vlinkz).
    # If this attribute is ever renamed upstream the rebuild will say so —
    # try `.nix-software-center` instead of `.default`.
    inputs.nix-software-center.packages.${pkgs.system}.default
    kdePackages.discover     # Flatpak + firmware front-end (pairs with fwupd)

    # ---------- Media ----------
    haruna
    vlc
    qimgv

    # ---------- Monitoring ----------
    btop
    nvtopPackages.nvidia

    # ---------- Archive ----------
    kdePackages.ark
    p7zip unzip unrar

    # ---------- Basics ----------
    git curl
    fastfetch                # replaces neofetch (archived upstream)
  ];

  # LACT — GPU monitoring/clocks/power-limit.
  services.lact.enable = true;
}
