{ config, pkgs, ... }:

{
  networking.networkmanager.enable = true;
  networking.firewall.enable = true;

  # ---------- Mullvad (GUI app + daemon) ----------
  services.mullvad-vpn = {
    enable = true;
    package = pkgs.mullvad-vpn;   # GUI variant
  };

  # ---------- Cloudflare WARP (daemon; toggled via warp-cli) ----------
  # RULE OF THE HOUSE: never CONNECT both at once — they fight over routing.
  # Both daemons idling is fine; one tunnel active at a time.
  #   warp-on / warp-off aliases live in fish (modules/shell.nix note).
  # First-time setup: warp-cli registration new
  services.cloudflare-warp.enable = true;
}
