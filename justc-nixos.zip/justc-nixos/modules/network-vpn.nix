{ config, lib, pkgs, havePkg, missingPkgs, ... }:

{
  networking.networkmanager.enable = true;
  networking.firewall.enable = true;

  # ---------- Mullvad (GUI app + daemon) ----------
  # Guarded: if the attribute is renamed upstream the service is switched off
  # rather than aborting the install. `missingpkgs` will name it.
  justc.missingPackages = missingPkgs [ "mullvad-vpn" ];
  services.mullvad-vpn = lib.mkIf (havePkg "mullvad-vpn" null != null) {
    enable = true;
    package = havePkg "mullvad-vpn" null;   # GUI variant
  };

  # ---------- Cloudflare WARP (daemon; toggled via warp-cli) ----------
  # RULE OF THE HOUSE: never CONNECT both at once — they fight over routing.
  # Both daemons idling is fine; one tunnel active at a time.
  #   warp-on / warp-off aliases live in fish (modules/shell.nix note).
  # First-time setup: warp-cli registration new
  services.cloudflare-warp.enable = true;
}
