{ config, pkgs, havePkgs, missingPkgs, ... }:

{
  programs.fish.enable = true;   # user shell is set in hosts/justc/default.nix

  justc.missingPackages = missingPkgs [ "starship" ];
  environment.systemPackages = havePkgs [
    "starship"   # initialized in dotfiles/fish/config.fish
  ];

  # Aliases (nrs, nup, warp-on/off) intentionally live in
  # dotfiles/fish/config.fish so you can edit them without a rebuild —
  # consistent with your KDL/own-config philosophy.
}
