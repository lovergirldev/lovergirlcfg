{ config, pkgs, ... }:

{
  programs.steam = {
    enable = true;
    remotePlay.openFirewall = true;
  };

  # Games can request performance governor etc.; add `gamemoderun %command%`
  # to a game's Steam launch options to use it.
  programs.gamemode.enable = true;
}
