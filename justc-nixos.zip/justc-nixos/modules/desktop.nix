{ config, pkgs, lib, ... }:

let
  pick = expr: fallback:
    let r = builtins.tryEval expr; in if r.success then r.value else fallback;

  colloidIcons = pick
    (pkgs.colloid-icon-theme.override { colorVariants = [ "pink" ]; })
    pkgs.colloid-icon-theme;

  colloidGtk = pick
    (pkgs.colloid-gtk-theme.override {
      themeVariants = [ "pink" ];
      colorVariants = [ "dark" ];
      tweaks = [ "black" ];
    })
    pkgs.colloid-gtk-theme;

  cursors = pkgs.posy-cursors or pkgs.bibata-cursors;

  # ------------------------------------------------------------------
  # theme-apply — detects the real installed theme folder names and applies
  # them. Runs at every login; re-run by hand any time.
  #
  # BUGFIX 3: it used to `cat >` settings.ini, destroying anything you had
  # added by hand (and silently overwriting the copies link.sh ships). It now
  # MERGES: it rewrites only the keys it owns and preserves every other line.
  #
  # BUGFIX 4: XCURSOR_THEME used to be hardcoded to "Posy_Cursor" in
  # environment.sessionVariables while this script auto-detected the real
  # name. When they disagreed, XWayland apps showed a different cursor from
  # Wayland ones. The env var is now written HERE, from the detected name.
  # ------------------------------------------------------------------
  themeApply = pkgs.writeShellScriptBin "theme-apply" ''
    set -uo pipefail
    export PATH=${pkgs.glib}/bin:${pkgs.coreutils}/bin:${pkgs.gnused}/bin:${pkgs.gnugrep}/bin:${pkgs.systemd}/bin:$PATH

    dirs="/run/current-system/sw/share $HOME/.nix-profile/share $HOME/.local/share"

    look() {
      sub=$1; shift
      for d in $dirs; do
        [ -d "$d/$sub" ] || continue
        ls "$d/$sub" 2>/dev/null
      done | grep -i "$@" | head -1
    }

    gtk=$(look themes -E "^Colloid.*[Pp]ink.*[Dd]ark")
    [ -n "$gtk" ] || gtk=$(look themes -E "^Colloid.*[Dd]ark")
    [ -n "$gtk" ] || gtk=$(look themes -E "^Colloid")
    [ -n "$gtk" ] || gtk="Adwaita-dark"

    icons=$(look icons -E "^Colloid.*[Pp]ink")
    [ -n "$icons" ] || icons=$(look icons -E "^Colloid")
    [ -n "$icons" ] || icons=$(look icons -E "^Papirus-Dark")
    [ -n "$icons" ] || icons="Adwaita"

    cursor=$(look icons -E "^Posy.*")
    [ -n "$cursor" ] || cursor=$(look icons -E "^Bibata")
    [ -n "$cursor" ] || cursor="Adwaita"

    echo "theme-apply: gtk=$gtk icons=$icons cursor=$cursor"

    # ---- merge into gtk-3.0 / gtk-4.0 settings.ini ----
    managed="gtk-theme-name gtk-icon-theme-name gtk-cursor-theme-name gtk-cursor-theme-size gtk-font-name gtk-application-prefer-dark-theme"

    for v in 3.0 4.0; do
      d="$HOME/.config/gtk-$v"
      f="$d/settings.ini"
      mkdir -p "$d"
      keep=""
      if [ -f "$f" ]; then
        keep=$(grep -v '^\[Settings\]' "$f" 2>/dev/null | while IFS= read -r line; do
          k=$(echo "$line" | sed -n 's/^\([a-zA-Z0-9-]*\)[[:space:]]*=.*/\1/p')
          skip=0
          for m in $managed; do [ "$k" = "$m" ] && skip=1; done
          [ "$skip" = "0" ] && echo "$line"
        done)
      fi
      {
        echo "[Settings]"
        echo "gtk-theme-name=$gtk"
        echo "gtk-icon-theme-name=$icons"
        echo "gtk-cursor-theme-name=$cursor"
        echo "gtk-cursor-theme-size=24"
        echo "gtk-font-name=Space Grotesk 11"
        echo "gtk-application-prefer-dark-theme=1"
        [ -n "$keep" ] && echo "$keep"
      } > "$f.tmp" && mv "$f.tmp" "$f"
    done

    # ---- gsettings (portals + GNOME-flavoured apps) ----
    gsettings set org.gnome.desktop.interface gtk-theme "$gtk" 2>/dev/null || true
    gsettings set org.gnome.desktop.interface icon-theme "$icons" 2>/dev/null || true
    gsettings set org.gnome.desktop.interface cursor-theme "$cursor" 2>/dev/null || true
    gsettings set org.gnome.desktop.interface cursor-size 24 2>/dev/null || true
    gsettings set org.gnome.desktop.interface font-name "Space Grotesk 11" 2>/dev/null || true
    gsettings set org.gnome.desktop.interface document-font-name "Space Grotesk 11" 2>/dev/null || true
    gsettings set org.gnome.desktop.interface monospace-font-name "Rec Mono Linear 11" 2>/dev/null || true
    gsettings set org.gnome.desktop.interface color-scheme "prefer-dark" 2>/dev/null || true

    # ---- cursor env, from the DETECTED name (bugfix 4) ----
    mkdir -p "$HOME/.config/environment.d"
    printf 'XCURSOR_THEME=%s\nXCURSOR_SIZE=24\n' "$cursor" \
      > "$HOME/.config/environment.d/10-justc-cursor.conf"
    systemctl --user set-environment XCURSOR_THEME="$cursor" XCURSOR_SIZE=24 2>/dev/null || true

    # niri's own cursor line (it live-reloads)
    niri_cfg="$HOME/.config/niri/config.kdl"
    if [ -f "$niri_cfg" ] && ! grep -q "xcursor-theme \"$cursor\"" "$niri_cfg"; then
      sed -i "s|xcursor-theme \".*\"|xcursor-theme \"$cursor\"|" "$niri_cfg"
      echo "theme-apply: niri cursor set to $cursor"
    fi

    mkdir -p "$HOME/.icons"
    ln -sfn "$(for d in $dirs; do [ -d "$d/icons/$cursor" ] && echo "$d/icons/$cursor" && break; done)" "$HOME/.icons/default" 2>/dev/null || true
  '';
  # ------------------------------------------------------------------
  # plasma-oxygen — set Plasma's Global Theme + color scheme to Oxygen Dark.
  # Detection, not hardcoding: lists what's actually installed and picks the
  # best Oxygen match, falling back to Breeze Dark so this can never leave
  # Plasma in a broken state.
  # ------------------------------------------------------------------
  plasmaOxygen = pkgs.writeShellScriptBin "plasma-oxygen" ''
    set -uo pipefail
    export PATH=${pkgs.coreutils}/bin:${pkgs.gnugrep}/bin:${pkgs.gnused}/bin:$PATH

    dirs="/run/current-system/sw/share $HOME/.nix-profile/share $HOME/.local/share"

    find_in() {  # find_in <subdir> <regex...>
      sub=$1; shift
      for d in $dirs; do
        [ -d "$d/$sub" ] || continue
        ls "$d/$sub" 2>/dev/null
      done | grep -i "$@" | head -1
    }

    # --- Global Theme (look-and-feel package id) ---
    lnf=$(find_in plasma/look-and-feel -E "oxygen.*dark|dark.*oxygen")
    [ -n "$lnf" ] || lnf=$(find_in plasma/look-and-feel -E "oxygen")
    [ -n "$lnf" ] || lnf="org.kde.breezedark.desktop"

    # --- Plasma Style (desktop theme) ---
    style=$(find_in plasma/desktoptheme -E "^oxygen")
    [ -n "$style" ] || style="breeze-dark"

    # --- Color scheme (.colors file, name without extension) ---
    colors=$(find_in color-schemes -E "oxygen.*dark|dark.*oxygen")
    [ -n "$colors" ] || colors=$(find_in color-schemes -E "oxygen")
    [ -n "$colors" ] || colors="BreezeDark.colors"
    colors="''${colors%.colors}"

    echo "plasma-oxygen: global=$lnf style=$style colors=$colors"

    # If Plasma is actually running, its own tool does the job properly
    # (it updates every dependent key at once). Otherwise write the keys.
    if command -v plasma-apply-lookandfeel >/dev/null 2>&1 \
       && [ -n "''${KDE_FULL_SESSION:-}" ]; then
      plasma-apply-lookandfeel -a "$lnf" 2>/dev/null || true
      command -v plasma-apply-desktoptheme >/dev/null 2>&1 \
        && plasma-apply-desktoptheme "$style" 2>/dev/null || true
      command -v plasma-apply-colorscheme >/dev/null 2>&1 \
        && plasma-apply-colorscheme "$colors" 2>/dev/null || true
      echo "plasma-oxygen: applied live"
      exit 0
    fi

    # --- offline: write the keys Plasma reads at startup ---
    setkey() { # setkey <file> <group> <key> <value>
      f="$HOME/.config/$1"; g="$2"; k="$3"; v="$4"
      mkdir -p "$(dirname "$f")"
      touch "$f"
      if grep -q "^\[$g\]" "$f"; then
        if sed -n "/^\[$g\]/,/^\[/p" "$f" | grep -q "^$k="; then
          sed -i "/^\[$g\]/,/^\[/ s|^$k=.*|$k=$v|" "$f"
        else
          sed -i "/^\[$g\]/a $k=$v" "$f"
        fi
      else
        printf '\n[%s]\n%s=%s\n' "$g" "$k" "$v" >> "$f"
      fi
    }

    setkey kdeglobals General         ColorScheme "$colors"
    setkey kdeglobals KDE             LookAndFeelPackage "$lnf"
    setkey kdeglobals Icons           Theme "$(find_in icons -E "^oxygen$" || echo breeze-dark)"
    setkey plasmarc   Theme           name "$style"
    setkey kwinrc     org.kde.kdecoration2 library "org.kde.oxygen"

    echo "plasma-oxygen: keys written (takes effect next Plasma login)"
  '';

in
{
  # ---------- Plasma default look: Oxygen Dark ----------
  # Plasma 6.7 revived Oxygen (the KDE 4 default) as a full Global Theme with
  # light/dark/twilight variants — that revival is a large part of why this
  # config runs KDE from unstable at all.
  #
  # You don't run Home Manager, so there's no plasma-manager to do this
  # declaratively. Instead this writes Plasma's own config keys ONCE, the
  # first time the account exists, and then never touches them again — so
  # anything you change later in System Settings sticks.
  #
  # It DETECTS the theme id rather than hardcoding it, for the same reason
  # theme-apply does: look-and-feel package ids drift, and a hardcoded id that
  # stops matching is exactly how a theme silently half-applies.
  #
  # Re-run by hand any time:  plasma-oxygen
  # Undo:                     delete ~/.local/state/justc-plasma-defaults-applied
  #                           and log out/in, or just pick a theme in
  #                           System Settings > Colors / Global Theme.

  # ---------- Login / greeter ----------
  # SDDM stays the default: it is Qt, it themes with Plasma, and it is the
  # thing that lets you pick the Plasma session when niri misbehaves.
  # Alternatives are written up in GREETER.md — swapping is a ~6 line edit.
  services.displayManager.sddm = {
    enable = true;
    wayland.enable = true;   # if SDDM ever black-screens on nvidia, set false
  };
  services.displayManager.defaultSession = "niri";

  # ---------- Sessions ----------
  # Plasma comes from unstable (6.7.x) — see plasmaUnstable in
  # hosts/justc/default.nix. One word reverts it to stable 6.6.x.
  services.desktopManager.plasma6.enable = true;
  programs.niri.enable = true;

  environment.systemPackages = with pkgs; [
    ghostty
    alacritty

    waybar
    eww                     # the seven applets (GTK, so real inset shadows)
    rofi                    # still drives the launcher + power menu
    swaynotificationcenter
    hyprlock hypridle
    swww
    xwayland-satellite
    networkmanagerapplet

    brightnessctl playerctl wl-clipboard cliphist
    pavucontrol blueman libnotify acpi wlsunset
    rofimoji

    # waybar module helpers (new modules in config.jsonc shell out to these)
    power-profiles-daemon    # powerprofilesctl — power profile widget
    jq                       # VPN / conserve widget JSON
    lm_sensors               # CPU temp

    yazi
    ffmpegthumbnailer poppler-utils ripgrep fd

    colloidIcons
    colloidGtk
    cursors
    themeApply
    plasmaOxygen
    gsettings-desktop-schemas glib
  ];

  # ---------- Portals ----------
  # xdg-desktop-portal-gtk is also what Flatpak apps use for file pickers,
  # so it matters more now than it did.
  xdg.portal = {
    enable = true;
    xdgOpenUsePortal = true;
    extraPortals = with pkgs; [
      xdg-desktop-portal-gtk
      xdg-desktop-portal-gnome
    ];
  };

  services.gnome.gnome-keyring.enable = true;
  security.pam.services.sddm.enableGnomeKeyring = true;

  systemd.user.services.polkit-gnome-agent = {
    description = "polkit-gnome authentication agent";
    wantedBy = [ "graphical-session.target" ];
    after = [ "graphical-session.target" ];
    serviceConfig = {
      Type = "simple";
      ExecStart = "${pkgs.polkit_gnome}/libexec/polkit-gnome-authentication-agent-1";
      Restart = "on-failure";
    };
  };

  programs.dconf.enable = true;

  # Runs plasma-oxygen ONCE, ever. The stamp file means anything you change
  # later in System Settings is never clobbered on a subsequent login.
  systemd.user.services.plasma-defaults = {
    description = "Apply Oxygen Dark as the Plasma default (first login only)";
    wantedBy = [ "graphical-session.target" ];
    after = [ "graphical-session.target" ];
    serviceConfig = {
      Type = "oneshot";
      RemainAfterExit = true;
    };
    script = ''
      stamp="$HOME/.local/state/justc-plasma-defaults-applied"
      [ -e "$stamp" ] && exit 0
      mkdir -p "$(dirname "$stamp")"
      ${plasmaOxygen}/bin/plasma-oxygen || true
      touch "$stamp"
    '';
  };

  systemd.user.services.theme-apply = {
    description = "Apply justc GTK/icon/cursor theme names";
    wantedBy = [ "graphical-session.target" ];
    after = [ "graphical-session.target" ];
    serviceConfig = {
      Type = "oneshot";
      RemainAfterExit = true;
      ExecStart = "${themeApply}/bin/theme-apply";
    };
  };

  # BUGFIX 4: XCURSOR_THEME is deliberately NOT set here any more.
  # theme-apply writes it from the name it actually detected.
  environment.sessionVariables = {
    NIXOS_OZONE_WL = "1";
  };

  # ---------- Fonts ----------
  fonts = {
    packages = with pkgs; [
      space-grotesk
      recursive
      nerd-fonts.jetbrains-mono
      noto-fonts
      noto-fonts-color-emoji
    ];
    fontconfig.defaultFonts = {
      sansSerif = [ "Space Grotesk" "Noto Sans" ];
      monospace = [ "Rec Mono Linear" "JetBrainsMono Nerd Font" ];
      emoji = [ "Noto Color Emoji" ];
    };
  };
}
