# ============================================================================
# NOT IN USE — REMOVED FROM THE BUILD IN SESSION 5
# ============================================================================
# This file is kept for reference only. It is NOT imported, and the `nixvim`
# flake input it depends on has also been removed, so re-adding the import
# alone will NOT work.
#
# Why it was removed: the input tracked nixvim's main branch while nixpkgs is
# pinned to a stable release. nixvim publishes matching release branches
# precisely because that pairing breaks, and this module's surface (9 plugins
# + 5 LSP servers) meant any renamed option was a hard evaluation error that
# would stop the whole install.
#
# To bring it back, BOTH steps are required:
#   1. flake.nix   — restore the nixvim input, pinned to the branch matching
#                    the nixpkgs release (e.g. nixvim/nixos-26.05)
#   2. hosts/justc/default.nix — uncomment ../../modules/nixvim.nix
# ============================================================================

# Declarative Neovim, built STANDALONE — no Home Manager, per your dotfiles
# philosophy. nixvim produces one self-contained binary with plugins baked in.
#
# It installs as `nvix`, NOT `nvim`. Plain `nvim` stays plain Neovim reading
# your own ~/.config/nvim, so nothing you write by hand is shadowed.
#
# IF THIS FILE EVER BREAKS A REBUILD: comment out the one line
#   ../../modules/nixvim.nix
# in hosts/justc/default.nix and rebuild. Nothing else depends on it.

{ config, pkgs, lib, inputs, ... }:

let
  nixvimLib = inputs.nixvim.legacyPackages.${pkgs.system};

  nvix = nixvimLib.makeNixvimWithModule {
    inherit pkgs;
    module = {
      viAlias = false;    # deliberately NOT stealing vi/vim/nvim
      vimAlias = false;

      globals.mapleader = " ";

      opts = {
        number = true;
        relativenumber = true;
        shiftwidth = 2;
        tabstop = 2;
        expandtab = true;
        smartindent = true;
        wrap = false;
        termguicolors = true;
        signcolumn = "yes";
        cursorline = true;
        scrolloff = 8;
        updatetime = 250;
        undofile = true;
        ignorecase = true;
        smartcase = true;
      };

      # justc palette: inky black + amber — matches ghostty, starship and
      # yazi. This is the 'terminal family'; everything outside a shell
      # session (waybar, rofi, notifications, lock screen) is pink instead —
      # see THEME.md.
      colorschemes.base16 = {
        enable = true;
        colorscheme = {
          base00 = "#16181d";   # bg
          base01 = "#1c1f26";   # raised
          base02 = "#262a33";   # selection
          base03 = "#878d99";   # comments
          base04 = "#a8aeb9";
          base05 = "#e3e5ea";   # fg
          base06 = "#e3e5ea";
          base07 = "#ffffff";
          base08 = "#e5715c";   # red
          base09 = "#c98a52";   # amber dim
          base0A = "#ffb26b";   # amber accent
          base0B = "#86c9a0";   # green
          base0C = "#86c7c7";   # cyan
          base0D = "#7fa9d6";   # blue
          base0E = "#b89ad9";   # magenta
          base0F = "#e8c07a";
        };
      };

      plugins = {
        lualine.enable = true;
        telescope.enable = true;
        treesitter.enable = true;
        gitsigns.enable = true;
        which-key.enable = true;
        comment.enable = true;
        nvim-autopairs.enable = true;
        web-devicons.enable = true;

        lsp = {
          enable = true;
          servers = {
            nixd.enable = true;      # Nix
            lua_ls.enable = true;
            bashls.enable = true;
            pyright.enable = true;
            ts_ls.enable = true;
          };
        };

        cmp = {
          enable = true;
          autoEnableSources = true;
          settings.sources = [
            { name = "nvim_lsp"; }
            { name = "path"; }
            { name = "buffer"; }
          ];
        };
      };

      keymaps = [
        { mode = "n"; key = "<leader>ff"; action = "<cmd>Telescope find_files<cr>"; }
        { mode = "n"; key = "<leader>fg"; action = "<cmd>Telescope live_grep<cr>"; }
        { mode = "n"; key = "<leader>fb"; action = "<cmd>Telescope buffers<cr>"; }
        { mode = "n"; key = "<leader>w";  action = "<cmd>w<cr>"; }
        { mode = "n"; key = "<Esc>";      action = "<cmd>nohlsearch<cr>"; }
      ];
    };
  };
in
{
  environment.systemPackages = [
    (pkgs.writeShellScriptBin "nvix" ''exec ${nvix}/bin/nvim "$@"'')
  ];
}
