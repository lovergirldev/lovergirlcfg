# modules/guard.nix
#
# WHY THIS EXISTS
# ---------------
# This config names ~83 nixpkgs attributes. nixpkgs renames things between
# releases (poppler_utils -> poppler-utils, space-grotesk, and so on), and Nix
# aborts on the FIRST undefined variable it meets. That means a stale name
# costs a whole install cycle to discover, and only ever reveals one at a time
# — which is exactly how three cycles got burned before this file existed.
#
# Anything routed through `havePkgs` below is looked up BY STRING rather than
# as a bare identifier. A name that no longer exists is dropped instead of
# aborting the evaluation, and every dropped name is recorded so you see the
# COMPLETE list at once rather than one per reboot.
#
#   After first boot:    missingpkgs
#   Or read it directly: cat /etc/justc/missing-packages
#
# THE TRADE, STATED PLAINLY: a dropped package is NOT installed. This swaps
# "the install cannot finish" for "something might be quietly absent". That is
# the right trade for getting the system up, and the wrong one to leave in
# place forever. Run `missingpkgs` once you have booted and fix the names
# properly — then this file is just a safety net rather than a crutch.

{ config, lib, pkgs, ... }:

let
  get    = n: lib.attrByPath (lib.splitString "." n) null pkgs;
  exists = n: get n != null;
in
{
  options.justc.missingPackages = lib.mkOption {
    type = lib.types.listOf lib.types.str;
    default = [ ];
    description = "Package names this config asked for that are absent from this nixpkgs.";
  };

  # Injected into every module. Use:
  #   havePkgs [ "foo" "bar" ]      instead of   with pkgs; [ foo bar ]
  #   havePkg  "foo" fallback       instead of   pkgs.foo or fallback
  #   missingPkgs [ "foo" "bar" ]   to report what was dropped
  _module.args = {
    havePkgs    = names: map get (lib.filter exists names);
    missingPkgs = names: lib.filter (n: !(exists n)) names;
    havePkg     = n: fallback: if exists n then get n else fallback;
  };

  config =
    let
      miss   = lib.unique (builtins.sort (a: b: a < b) config.justc.missingPackages);
      report =
        if miss == [ ]
        then "none — every package name in this config resolved.\n"
        else lib.concatMapStrings (n: "${n}\n") miss;
    in
    {
      environment.etc."justc/missing-packages".text = report;

      environment.systemPackages = [
        (pkgs.writeShellScriptBin "missingpkgs" ''
          echo "Package names this config asked for but this nixpkgs does not have."
          echo "Each one was SKIPPED, so it is not installed:"
          echo
          cat /etc/justc/missing-packages
        '')
      ];

      # Surfaces the same list during the build, so it lands in the install log
      # as well as on the installed system.
      warnings = lib.optional (miss != [ ]) ''
        justc: ${toString (builtins.length miss)} package name(s) are not in this
        nixpkgs and were SKIPPED: ${lib.concatStringsSep ", " miss}
        Run `missingpkgs` after boot for the same list.
      '';
    };
}
