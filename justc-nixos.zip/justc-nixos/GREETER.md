# Greeter options

**Shipped: SDDM (Wayland), default session niri.** Not changed, deliberately —
SDDM is the thing that lets you pick the Plasma session when niri won't start,
and it's Qt, so it follows Plasma's theming. Everything below is a swap you
can make later; each is a small edit to `modules/desktop.nix`.

---

## 1. Keep SDDM, theme it

Cheapest option. SDDM themes are packages.

```nix
services.displayManager.sddm = {
  enable = true;
  wayland.enable = true;
  theme = "catppuccin-mocha";                       # whatever you install
  extraPackages = [ pkgs.kdePackages.qtsvg pkgs.kdePackages.qtmultimedia ];
};
environment.systemPackages = [ pkgs.sddm-astronaut ];
```

Notable: `sddm-astronaut` (many variants, video backgrounds),
`sddm-sugar-candy` (the classic blurred-photo one), `where-is-my-sddm-theme`
(deliberately minimal — a bare prompt on a flat colour, which honestly suits
your inky-black-and-pink brief better than anything ornate).

**Trap:** SDDM themes need the Qt modules they use listed in `extraPackages`
or you get a blank screen with no error. That is the #1 way people lock
themselves out at the login screen.

## 2. regreet — the one that matches your theme for free

GTK-based, so it inherits Colloid + Space Grotesk + your pink accent
automatically via the same `theme-apply` names. This is the option that would
look most like the rest of the system with the least work.

```nix
services.displayManager.sddm.enable = false;
services.greetd = {
  enable = true;
  settings.default_session = {
    command = "${pkgs.greetd.regreet}/bin/regreet";
    user = "greeter";
  };
};
programs.regreet = {
  enable = true;
  settings = {
    background.path = "/home/lovergirlonline/Pictures/wall.png";
    GTK = {
      application_prefer_dark_theme = true;
      cursor_theme_name = "Posy_Cursor";
      font_name = "Space Grotesk 12";
      icon_theme_name = "Colloid-pink-dark";
      theme_name = "Colloid-Pink-Dark";
    };
  };
};
```

**Cost:** greetd has no session picker as rich as SDDM's. You get a dropdown,
but if it misbehaves your Plasma escape hatch is harder to reach. Given how
much this machine has fought you at boot, that's a real trade.

## 3. tuigreet — pure terminal, no graphics stack at all

The most robust option that exists. If your GPU driver is broken, this still
works, because it's a TTY. Fits the retro-computing side of your brief.

```nix
services.displayManager.sddm.enable = false;
services.greetd = {
  enable = true;
  settings.default_session = {
    command = "${pkgs.greetd.tuigreet}/bin/tuigreet --time --remember --remember-user-session --asterisks --cmd niri";
    user = "greeter";
  };
};
# stop boot logs from scribbling over it
systemd.services.greetd.serviceConfig = {
  Type = "idle";
  StandardInput = "tty";
  StandardOutput = "tty";
  TTYReset = true;
  TTYVHangup = true;
  TTYVTDisallocate = true;
};
```

`--remember-user-session` means it reopens whatever you used last, so the
Plasma escape hatch survives. This is the one I'd pick if you want a change.

## 4. No greeter — autologin into niri

LUKS already asked for a passphrase, so a second password is arguably
redundant on a single-user laptop.

```nix
services.greetd = {
  enable = true;
  settings.initial_session = { command = "niri-session"; user = "lovergirlonline"; };
  settings.default_session = { command = "niri-session"; user = "lovergirlonline"; };
};
```

**Cost:** you lose the session picker entirely — reaching Plasma then means
editing the config or using a TTY. Combine with a hyprlock-on-idle setup or
your screen is unlocked whenever the lid is open.

---

## Recommendation

Leave SDDM alone until Limine and Plasma 6.7 have both proven themselves on
this machine. Changing the bootloader and the greeter in the same reinstall
means that if you can't get to a login prompt, you won't know which one did
it. Once you've booted successfully a few times, **tuigreet** is the change
I'd make — it can't break in a way that graphics drivers cause.
