# justc — NixOS for the Legion Slim 7 16IRH8 (82Y3)

Everything decided in our planning conversation, as one flake: dGPU-always with a
hybrid boot entry, LUKS unlocked by USB key (passphrase fallback), Btrfs +
snapshots, niri (default) + Plasma, Windows 11 chainload, and the full app list —
Helium, Affinity v3, Resolve Studio, Steam, Filen, both VPNs, the lot.

## Repo map

```
flake.nix                     inputs: stable + unstable, disko, affinity-nix, helium
hosts/justc/
  default.nix                 identity, user, locale, unstable overlay, nix settings
  disko.nix                   disk layout (ESP + LUKS + Btrfs subvols)      CHANGEME #1
  boot.nix                    Limine, Windows entry, USB keyfile            auto-detected
  modules/extras.nix          requested GitHub repos — read its header      see notes inside
  graphics.nix                NVIDIA dGPU-always + hybrid specialisation    CHANGEME #4
  hardware-configuration.nix  STUB — replaced at install (step 6)
  legion.nix                  power modes, conserve script, experimental extras
modules/                      desktop, apps, gaming, vpn, shell, services
dotfiles/                     niri, waybar, ghostty, fish, starship, rofi, hyprlock/idle
  link.sh                     copys dotfiles into ~/.config
```

## The four CHANGEMEs

1. **`disko.nix`** — target SSD device path (the one WITHOUT Windows).
2. **`boot.nix`** — `/dev/disk/by-id/usb-…` of your LUKS key stick.
3. **`boot.nix`** — Windows `efiDeviceHandle` (from the UEFI shell, step 10).
4. **`graphics.nix`** — PRIME bus IDs; defaults are almost certainly right,
   verify before first *hybrid* boot only.

---

## Install day

**Bring:** NixOS **graphical** ISO on a USB (make it with Ventoy on Windows),
a second cheap USB stick (LUKS key — gets partially overwritten), optionally a
third (key backup). Windows drive stays untouched; Secure Boot is already off
on your machine, so no BIOS prep needed. BIOS graphics can stay **Discrete**.

**0. Push this repo somewhere first** (GitHub etc.), or you'll be typing it.
If it must stay private, you can also just download it as a zip inside the
live session's browser.

**1. Boot the ISO** (F12 → your USB). You land in a Plasma live desktop.
Connect Wi-Fi from the tray. Open Konsole. Get the repo:

```bash
git clone https://github.com/YOU/justc-nixos ~/nixos && cd ~/nixos
```

**2. Identify the disks and set CHANGEME #1:**

```bash
lsblk -o NAME,SIZE,MODEL,FSTYPE
```

The Windows disk shows `ntfs` partitions — the *other* nvme is your target.
Edit `hosts/justc/disko.nix` accordingly (`nano` works; the live session also
has a GUI editor).

**3. Partition + encrypt + mount (⚠ erases the target disk):**

```bash
echo -n 'YOUR-LUKS-PASSPHRASE' > /tmp/luks.pass
sudo nix --experimental-features "nix-command flakes" \
  run github:nix-community/disko/latest -- \
  --mode destroy,format,mount --flake .#justc
```

When it finishes, `findmnt /mnt` should show btrfs on `/mnt`.

**4. Write the key to the USB stick.** Plug the key stick in, then:

```bash
ls -l /dev/disk/by-id/ | grep -i usb        # find it — note the exact name
KEY=/dev/disk/by-id/usb-XXXX                # ← paste yours (NOT the -part1 one)
sudo dd if=/dev/urandom of=$KEY bs=4096 seek=2560 count=1 conv=fsync
```

(4096 bytes of random key at a 10 MiB offset — the stick still looks blank.)

**5. Enroll the key + set CHANGEME #2:**

```bash
LUKSPART=/dev/nvme0n1p2                     # ← partition 2 of your TARGET disk
sudo cryptsetup luksAddKey $LUKSPART $KEY \
  --new-keyfile-offset 10485760 --new-keyfile-size 4096
```

(It asks for the passphrase to authorize.) Put the `usb-XXXX` by-id path into
`boot.nix`. **Backup stick (recommended):** copy the same bytes to stick #3 —

```bash
sudo dd if=$KEY of=/tmp/key.bin bs=4096 skip=2560 count=1
sudo dd if=/tmp/key.bin of=/dev/disk/by-id/usb-BACKUPSTICK bs=4096 seek=2560 count=1 conv=fsync
```

Same key = same slot; nothing else to enroll. Label the sticks. Keep the
backup at home, primary on your keychain.

**6. Generate the real hardware config (replaces the stub):**

```bash
sudo nixos-generate-config --no-filesystems --root /mnt
cp /mnt/etc/nixos/hardware-configuration.nix hosts/justc/hardware-configuration.nix
```

**7. Commit — flakes only see git-tracked files:**

```bash
git add -A && git -c user.email=i@justc -c user.name=justc commit -m "install day"
```

**8. Install:**

```bash
sudo nixos-install --flake .#justc
```

First build is long (nvidia driver, Plasma, Resolve download). If the Affinity
input starts *compiling Wine* rather than downloading it, that's the cache
missing — let it run, it's one-time. Set the **root password** when prompted.

**9. Reboot** (remove the ISO stick, leave the key stick in). You should sail
past LUKS straight to SDDM. Pull the key stick out and reboot once more to
confirm the passphrase fallback appears after ~10s. Log in as
`lovergirlonline` / `changeme`, then immediately:

```bash
passwd
```

**10. Windows boot entry (CHANGEME #3).** Reboot → in the boot menu pick
**Windows boot entry — now automatic.**

`install.sh` finds the Windows ESP by looking for the NTFS partition's
neighbouring FAT partition, verifies `EFI/Microsoft/Boot/bootmgfw.efi` is
actually on it, and writes that partition's filesystem UUID into
`hosts/justc/boot.nix`. Limine then addresses it as `uuid(...)`, which is
immune to the nvme0/nvme1 name swap.

There is no EDK2 shell step any more, and no `HDxx` handle to find. If the
detection ever fails the installer says so and Windows stays reachable with
F12 at power-on.

Inspect the generated menu any time with `bootcfg`.

## Daily driving

| Task | Command |
|---|---|
| Rebuild after editing config | `nrs` |
| Update everything | `nup` |
| Something broke after update | reboot → pick previous generation in boot menu |
| Battery/travel mode | reboot → BIOS: graphics **Hybrid** → boot entry **(hybrid)** |
| Back to full power | reboot → BIOS: **Discrete** → normal boot entry |
| Run one app on dGPU (hybrid mode) | `nvidia-offload <command>` |
| Battery charge cap | `conserve on` / `off` |
| File snapshots | `snapper -c home list` |
| Lock now | Mod+Alt+L |

Before first hybrid boot: in Hybrid BIOS mode run
`lspci | grep -Ei 'vga|3d'` and confirm `graphics.nix` bus IDs
(00:02.0 → `PCI:0:2:0`, 01:00.0 → `PCI:1:0:0`).

## Experimental toggles (all shipped safe)

- **LenovoLegionLinux** (fan curves): commented out in `legion.nix` — support
  for this exact model is partial upstream. Uncomment, rebuild, re-comment if
  the module fails to build.
- **Ventoy**: commented out in `apps.nix` — nixpkgs flags its bundled blobs;
  instructions inline.
- **fprintd / OpenRGB**: enabled but honestly-labeled lotteries on this SKU.

## If something won't evaluate

Package names drift between releases. If a rebuild errors on an attribute
(likely candidates: `godot_4-mono`, `rofi`, `services.lact`), search
the current name at <https://search.nixos.org> and adjust the one line — each
risky attr has a comment next to it saying what to try. Two third-party inputs
(`affinity-nix`, `helium`) track their upstreams; if one breaks on update, pin
it by reverting `flake.lock` (`git checkout flake.lock`) until it's fixed.

## Notes to future-you

- `system.stateVersion` stays `"26.05"` forever, even after upgrading releases.
- New machine someday: clone repo, redo steps 2–8 with a new
  `hardware-configuration.nix` and disk path. Everything else replays.
- Lost the key stick: passphrase still unlocks; make a new key stick with
  steps 4–5 and update `boot.nix`.
- Adding Home Manager later is purely additive — dotfiles move under it
  whenever (if ever) you want build-time validation.
