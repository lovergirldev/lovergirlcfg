# preflight-options.nix
#
# Package NAMES are handled by modules/guard-args.nix — a stale one is skipped
# rather than fatal. Option NAMES cannot be guarded that way: a wrong option is
# always a hard evaluation error, and Nix stops at the first one, so each bad
# option costs a whole install cycle to discover.
#
# This file closes that gap. Option DECLARATIONS can be inspected without
# evaluating any config values, so every risky option path can be checked in a
# single run instead of one per reboot.
#
# install.sh runs this before it touches the disk. By hand:
#
#   nix eval --impure --raw --file preflight-options.nix --argstr flake "$PWD"

{ flake ? throw "pass --argstr flake <path to the flake>" }:

let
  self = builtins.getFlake flake;
  lib  = self.inputs.nixpkgs.lib;
  opts = self.nixosConfigurations.justc.options;

  has = p: lib.hasAttrByPath (lib.splitString "." p) opts;

  # Every option path this config sets that is either new this session or
  # otherwise not guaranteed to exist. Long-standing ones (boot.kernelPackages,
  # networking.*, users.*) are left out deliberately to keep the signal high.
  paths = [
    # the accepted risk — Limine, brand new here
    "boot.loader.limine.enable"
    "boot.loader.limine.efiSupport"
    "boot.loader.limine.maxGenerations"
    "boot.loader.limine.extraConfig"
    "boot.loader.limine.extraEntries"

    # the documented one-word rollback target, so verify it too
    "boot.loader.systemd-boot.enable"
    "boot.loader.systemd-boot.configurationLimit"
    "boot.loader.systemd-boot.edk2-uefi-shell.enable"

    # services added or changed in recent sessions
    "services.flatpak.enable"
    "services.blueman.enable"
    "services.lact.enable"
    "services.cloudflare-warp.enable"
    "services.mullvad-vpn.enable"
    "services.mullvad-vpn.package"
    "services.gnome.gnome-keyring.enable"
    "security.pam.services.sddm.enableGnomeKeyring"

    # compositor + misc
    "programs.niri.enable"
    "programs.dconf.enable"
    "boot.initrd.systemd.enable"
    "zramSwap.memoryPercent"
  ];

  missing = builtins.filter (p: !(has p)) paths;

  limineAvailable =
    if has "boot.loader.limine"
    then lib.concatStringsSep ", "
      (builtins.attrNames (lib.getAttrFromPath [ "boot" "loader" "limine" ] opts))
    else "!! boot.loader.limine does not exist in this nixpkgs at all !!";
in

(if missing == [ ]
 then "OPTIONS OK — every checked option path exists.\n"
 else "MISSING OPTIONS (each one is a hard failure):\n"
      + lib.concatMapStrings (p: "    " + p + "\n") missing)
+ "\nWhat boot.loader.limine actually offers here:\n    "
+ limineAvailable + "\n"
