{
  description = "justc — Lenovo Legion Slim 7 16IRH8 (82Y3) — NixOS";

  inputs = {
    # Stable base. 26.05 is current stable as of mid-2026.
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-26.05";

    # Unstable. Used selectively via overlay for: niri (blur),
    # xwayland-satellite, and — new — the whole KDE stack so Plasma is 6.7.
    nixpkgs-unstable.url = "github:NixOS/nixpkgs/nixos-unstable";

    # Declarative disk partitioning (LUKS + Btrfs subvolumes) — used on install day.
    disko = {
      url = "github:nix-community/disko/latest";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    # Affinity v3 via patched Wine (ElementalWarrior fork).
    # NOTE: do NOT add `inputs.nixpkgs.follows` here — it would bust their
    # binary cache and force a multi-hour Wine compile on your laptop.
    # The matching cache.garnix.io substituter is set in hosts/justc/default.nix.
    affinity-nix.url = "github:mrshmllow/affinity-nix";

    # Helium browser (not in nixpkgs yet; repackages official releases).
    helium = {
      url = "github:oxcl/nix-flake-helium-browser";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    # ---------------- new in this revision ----------------

    # Declarative Neovim. Built STANDALONE (no Home Manager) — see
    # modules/nixvim.nix. Ships as the `nvix` command; plain `nvim` stays yours.
    nixvim = {
      url = "github:nix-community/nixvim";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    # Nix User Repository — community packages, added as an overlay so they
    # appear at pkgs.nur.repos.<user>.<pkg>
    nur = {
      url = "github:nix-community/NUR";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    # GUI package manager for NixOS (vlinkz). Browse + install like a store.
    nix-software-center = {
      url = "github:vlinkz/nix-software-center";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = { self, nixpkgs, disko, ... }@inputs: {
    nixosConfigurations.justc = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      specialArgs = { inherit inputs; };
      modules = [
        disko.nixosModules.disko
        ./hosts/justc
      ];
    };
  };
}
