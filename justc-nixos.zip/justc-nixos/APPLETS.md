# Applets — moved from rofi to eww

## Why

Everything in this system expresses depth with shadows: raised faces have a lit
top edge and cast a shadow, controls press into wells. rofi's theme engine has
no shadow support, so the seven applets were the one place that language broke
down — they faked depth with layered surfaces instead.

eww is GTK, and GTK's CSS implements `box-shadow` including `inset`. So the
applets now get the real thing, and volume and brightness are **sliders sitting
in pressed-in wells** rather than lists of preset percentages.

rofi still drives the launcher (Mod+D) and the power menu (Mod+X). Those are
lists, which is what rofi is good at. Nothing there changed.

## Same keys as before

| Key | Applet | What's new vs the rofi version |
|---|---|---|
| `Mod+Shift+V` | volume | real slider, **plus a mic slider**, mute buttons that visibly depress, cycle-output button |
| `Mod+Shift+N` | brightness | real slider; presets kept as a quick row; night-light toggle shows its state |
| `Mod+Shift+I` | power | big % readout, charge bar, time remaining, profile buttons that stay pressed for the active one, conservation toggle |
| `Mod+Shift+B` | bluetooth | paired devices are **rows you click**, no second menu; connected ones stay pressed |
| `Mod+Shift+M` | media | album art, artist/title, transport row |
| `Mod+Shift+Q` | quicklinks | 2×3 grid of tiles |
| `Mod+Shift+S` | screenshot | tiles; the applet closes itself before the shot fires |

Waybar's volume, battery and bluetooth modules click through to the same three.

## How it hangs together

```
~/.config/eww/
  eww.yuck           widgets + the seven windows
  eww.scss           the material system — this is where the shadows live
  scripts/
    applet.sh        the ONLY entry point. Toggles, and closes the others first
    audio.sh  backlight.sh  power.sh  bt.sh  player.sh   data + actions
    open.sh   shot.sh                                    quicklinks / screenshot
```

`eww daemon` starts from niri's `spawn-at-startup`. `applet.sh` re-launches it
if it ever dies, so the keybinds are self-healing.

Windows anchor top-right at 52px down, clearing the floating bar. They are
`focusable "none"` on purpose: pointer input works fine on a layer surface, so
sliders drag normally, but an open applet never steals keyboard focus from
whatever you were typing in.

## Editing

- Colours and shadows: `dotfiles/eww/eww.scss`. The two recipes are the
  `@mixin raised` and `@mixin pressed` at the top — change those two and every
  control follows.
- After an edit: `ew` (alias for `eww reload`). If it gets stuck: `ewr`.
- Reset everything to shipped: `bash ~/nixos/dotfiles/link.sh`

## Rollback

The rofi applets are untouched at `~/.config/rofi/applets/bin/`. To go back,
edit the seven binds in `dotfiles/niri/config.kdl`:

```
~/.config/eww/scripts/applet.sh volume   ->   ~/.config/rofi/applets/bin/volume.sh
```

and the three `on-click` lines in `dotfiles/waybar/config.jsonc`. Nothing else
depends on eww.

## Untested, and worth knowing

I could not run eww against a live compositor while building this. The logic
and the data scripts are tested — every script returns a sane value with no
hardware present, so nothing can hand eww an empty string where it wants a
number. What I could not verify is eww's own parsing of `eww.yuck` on your
exact build.

First run, if a window doesn't appear:

```
eww logs
```

is the whole diagnostic. It names the file and line. Send me that output and
it'll be a one-line fix — a widget property renamed between eww versions is the
likely cause, not anything structural.
