# justc — reviewed NixOS configuration

This flake targets the Lenovo Legion Slim 7 16IRH8 (82Y3): NVIDIA dGPU mode
with a hybrid specialisation, LUKS, Btrfs, Limine, niri plus Plasma, and the
requested application and theme stack.

The included `install.sh` is a **reinstaller for the existing disk layout**. It
does not partition or format a blank disk.

## Required existing layout

The installer proceeds only when all of these are true:

- exactly one approximately 1 TB disk has a LUKS partition whose GPT label is
  `disk-main-luks`;
- that disk has a FAT ESP whose GPT label is `disk-main-esp`;
- the encrypted Btrfs filesystem contains `@`, `@home`, `@nix`, and
  `@snapshots`;
- `@` is an existing NixOS root;
- `@home/lovergirlonline` exists and is owned by UID 1000;
- the target disk has no NTFS partition; Windows is on another disk.

If any check differs, the installer stops instead of guessing.

## Install

Use a NixOS 26.05 graphical installer USB. Connect to the network, put
the reviewed installer and ZIP in the same directory, then run:

```bash
bash install-v9-reviewed.sh
```

The supplied pair is named `install-v9-reviewed.sh` and
`justc-nixos-v9-reviewed.zip`. You may instead extract the archive and run its
embedded `install.sh`. The v9 installer requires the archive's review marker,
so it will not silently combine with the original v8 source tree.

The script will:

1. identify the target by exact GPT labels and show its model and serial;
2. verify the LUKS mapping and all preserved Btrfs subvolumes;
3. generate this machine's hardware configuration and lock every flake input;
4. create temporary swap inside preserved `@nix`;
5. evaluate high-risk NixOS option paths;
6. perform a **real build of the complete system closure** directly into the
   preserved target Nix store while the old root is still intact;
7. validate the shipped niri file with the niri binary from that build;
8. ask you to type `REINSTALL justc`;
9. copy the NixOS ESP into `@nix/.justc-installer/`;
10. rename the old root to a timestamped `@rollback-…` subvolume;
11. install the already-built system, validate Limine and niri again, and ask
    you to choose the real login password interactively.

It never stores the login password in the flake or Nix store.
An existing `~/nixos` tree and every replaced dotfile are retained under a
per-run `~/.justc-installer-backup-…` directory.

Do not reboot if the script explicitly says automatic rollback failed. Save or
photograph the displayed log path and use [RECOVERY.md](RECOVERY.md).

## First-boot checklist

Keep the rollback root and ESP backup until all of these pass:

- Limine starts NixOS twice in a row;
- the LUKS passphrase unlocks the disk;
- SDDM accepts the password created during installation;
- both niri and Plasma can start from SDDM;
- Wi-Fi, audio, Bluetooth, suspend/resume, and the internal display work;
- `nvidia-smi`, `missingpkgs`, and `df -h /boot` look reasonable;
- Windows still starts with the firmware's F12 menu.

The installer also creates a timestamped Nix GC root for the previous system,
so weekly garbage collection cannot invalidate the rollback while you test.
`RECOVERY.md` explains the exact cleanup after you are satisfied.

The Limine Windows entry is a convenience. F12 is the authoritative fallback
because cross-disk EFI chainloading can be firmware-specific.

## Repository map

```text
flake.nix                     stable/unstable inputs and third-party flakes
hosts/justc/
  default.nix                 identity, user, overlays, Nix settings
  disko.nix                   expected ESP + LUKS + Btrfs layout
  boot.nix                    Limine, Windows entry, zram
  graphics.nix                NVIDIA dGPU default + hybrid specialisation
  hardware-configuration.nix  replaced by install.sh on the target machine
  legion.nix                  power profiles and Legion hardware helpers
modules/                      desktop, apps, gaming, VPN, shell, services
dotfiles/                     niri, Waybar, Ghostty, fish, rofi, Eww, etc.
  link.sh                     copies files into ~/.config with backups
preflight-options.nix         checks high-risk NixOS option names
AUDIT.md                      review findings, limits, and validation record
RECOVERY.md                   rollback procedure
```

`modules/nixvim.nix` is reference-only and is not imported. Plain `nvim` is
installed.

## Daily commands

| Task | Command |
|---|---|
| Rebuild after editing `~/nixos` | `nrs` |
| Update flake inputs and rebuild | `nup` |
| List guarded-out packages | `missingpkgs` |
| Recopy shipped dotfiles, with backups | `bash ~/nixos/dotfiles/link.sh` |
| Inspect Limine configuration | `bootcfg` |
| Check ESP free space | `espfree` |
| Battery conservation | `conserve on` / `conserve off` |

The generated `flake.lock` is copied into `~/nixos`. Keep it in version control
after the first successful install so later rebuilds remain reproducible.

## Hardware-specific notes

- Default graphics assumes BIOS **Discrete** mode.
- Before using the hybrid specialisation, boot once in BIOS **Hybrid** mode,
  run `lspci | grep -Ei 'vga|3d'`, and confirm the Intel/NVIDIA bus IDs in
  `hosts/justc/graphics.nix`.
- Fingerprint and OpenRGB support are hardware-dependent conveniences; neither
  is required for login or boot.
- Mullvad and Cloudflare WARP are both enabled, but never connect both tunnels
  at once.
- `system.stateVersion` is intentionally `"26.05"` and should not be raised
  during ordinary release upgrades.

For exact audit findings and remaining live-machine checks, read
[AUDIT.md](AUDIT.md).
