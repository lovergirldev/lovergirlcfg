# Recovery and rollback

`install.sh` keeps four recovery assets:

- the previous root as `@rollback-<UTC timestamp>`;
- a complete copy of the old NixOS ESP under
  `@nix/.justc-installer/esp-<UTC timestamp>`;
- the old `system` profile symlink as
  `@nix/.justc-installer/system-profile-<UTC timestamp>`;
- a `previous-system-<UTC timestamp>` GC root that prevents Nix from deleting
  the old system closure while the rollback is retained.

The exact names are printed at the end and recorded in the persistent install
log under `/nix/.justc-installer/`.

## If the installer itself fails

Before the full build and typed confirmation, the old root is never renamed.
After confirmation, the error trap attempts to:

1. remove only the partial new `@`;
2. rename the timestamped rollback root back to `@`;
3. restore the previous NixOS system-profile symlink;
4. remove the newly created NixOS bootloader paths and copy the saved ESP
   files back.

If the script reports that both restores succeeded, the old system should
remain bootable. If it reports that either restore failed, **do not reboot**.
Save the log path shown on screen.

## If the completed new system will not boot

Boot the NixOS installer USB and connect to a terminal. These commands assume
the exact labels that the installer verified:

```bash
sudo cryptsetup open /dev/disk/by-partlabel/disk-main-luks cryptroot
sudo mkdir -p /mnt/btrfs-top /mnt/esp
sudo mount -o subvolid=5 /dev/mapper/cryptroot /mnt/btrfs-top
sudo btrfs subvolume list /mnt/btrfs-top
```

Identify the exact timestamped `@rollback-…` name. Do not continue if there is
more than one and you are unsure which is the pre-install root.

Move the failed new root aside and restore the chosen old root, replacing the
example timestamp with the exact one you verified:

```bash
sudo mv /mnt/btrfs-top/@ /mnt/btrfs-top/@failed-YYYYMMDDTHHMMSSZ
sudo mv /mnt/btrfs-top/@rollback-YYYYMMDDTHHMMSSZ /mnt/btrfs-top/@
```

Restore the matching ESP copy:

```bash
sudo rm -f /mnt/btrfs-top/@nix/var/nix/profiles/system
sudo cp -a \
  /mnt/btrfs-top/@nix/.justc-installer/system-profile-YYYYMMDDTHHMMSSZ \
  /mnt/btrfs-top/@nix/var/nix/profiles/system
sudo mount -o umask=0077 /dev/disk/by-partlabel/disk-main-esp /mnt/esp
sudo rm -rf -- \
  /mnt/esp/loader \
  /mnt/esp/EFI/nixos \
  /mnt/esp/EFI/systemd \
  /mnt/esp/EFI/Linux \
  /mnt/esp/EFI/limine \
  /mnt/esp/EFI/BOOT/BOOTX64.EFI \
  /mnt/esp/limine \
  /mnt/esp/limine.conf
sudo cp -r -- /mnt/btrfs-top/@nix/.justc-installer/esp-YYYYMMDDTHHMMSSZ/. /mnt/esp/
sync
sudo umount /mnt/esp
sudo umount /mnt/btrfs-top
sudo cryptsetup close cryptroot
sudo reboot
```

Those removal targets are the same NixOS-only paths backed up and managed by
the installer. Do not broaden them, and do not remove `EFI/Microsoft`.

## If only niri is broken

At SDDM, choose the Plasma session. The installer validates the shipped niri
file with the built niri binary, but Plasma remains the independent escape
hatch for later configuration edits.

## Deleting the rollback

There is no need to delete it immediately. A Btrfs rollback subvolume initially
shares data with the old filesystem state and becomes more expensive only as
files diverge.

When you are fully satisfied, mount Btrfs subvolume ID 5, list the subvolumes,
and delete only the exact timestamped rollback name you verified. Remove its
matching protection symlink only after that:

```bash
sudo rm -f /nix/var/nix/gcroots/justc-installer/previous-system-YYYYMMDDTHHMMSSZ
```

Never use a wildcard for either cleanup.
