# ============================ STUB — REPLACE ME ============================
# install.sh replaces this automatically on the target machine with:
#
#   nixos-generate-config --no-filesystems --dir <temporary-directory>
#
# (--no-filesystems because disko.nix already declares the filesystems.)
# The generated file contains the initrd kernel modules for YOUR nvme/usb
# controllers — the system will not boot without it.
# ===========================================================================
{ ... }:
{
  # intentionally empty until replaced
}
