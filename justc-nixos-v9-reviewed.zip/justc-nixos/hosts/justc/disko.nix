# Declarative disk layout — used ONCE on install day by disko, then it also
# provides the fileSystems/luks entries for the running system.
#
# The device below is a harmless source-tree placeholder. install.sh rewrites
# its private working copy only after identifying the existing NixOS SSD by
# exact GPT labels, size, filesystem type, model, and serial. The reinstall
# path does not run Disko's destructive format mode.
{
  disko.devices.disk.main = {
    type = "disk";
    device = "/dev/nvme0n1";   # rewritten to /dev/disk/by-id/... by install.sh
    content = {
      type = "gpt";
      partitions = {
        esp = {
          size = "1G";
          type = "EF00";
          content = {
            type = "filesystem";
            format = "vfat";
            mountpoint = "/boot";
            mountOptions = [ "umask=0077" ];
          };
        };
        luks = {
          size = "100%";
          content = {
            type = "luks";
            name = "cryptroot";
            # Blank-disk Disko format mode only: it reads the passphrase from
            # this file. The reviewed reinstall script never runs that
            # destructive mode and does not need or create this file.
            passwordFile = "/tmp/luks.pass";
            settings.allowDiscards = true;
            content = {
              type = "btrfs";
              extraArgs = [ "-f" ];
              subvolumes = {
                "@" = {
                  mountpoint = "/";
                  mountOptions = [ "compress=zstd" "noatime" ];
                };
                "@home" = {
                  mountpoint = "/home";
                  mountOptions = [ "compress=zstd" "noatime" ];
                };
                "@nix" = {
                  mountpoint = "/nix";
                  mountOptions = [ "compress=zstd" "noatime" ];
                };
                "@snapshots" = {
                  mountpoint = "/.snapshots";
                  mountOptions = [ "compress=zstd" "noatime" ];
                };
              };
            };
          };
        };
      };
    };
  };
}
