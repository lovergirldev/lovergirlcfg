{ config, lib, pkgs, havePkg, missingPkgs, ... }:

let
  mullvadPkg = havePkg "mullvad-vpn" null;
  warpPkg = havePkg "cloudflare-warp" null;
in
{
  networking.networkmanager.enable = true;
  networking.firewall.enable = true;

  # ---------- Mullvad (GUI app + daemon) ----------
  # Guarded: if the attribute is renamed upstream the service is switched off
  # rather than aborting the install. `missingpkgs` will name it.
  justc.missingPackages = missingPkgs [ "mullvad-vpn" "cloudflare-warp" ];
  services.mullvad-vpn = lib.mkIf (mullvadPkg != null) {
    enable = true;
    package = mullvadPkg;   # GUI variant
  };

  # ---------- Cloudflare WARP (daemon; toggled via warp-cli) ----------
  # RULE OF THE HOUSE: never CONNECT both at once — they fight over routing.
  # Both daemons idling is fine; one tunnel active at a time.
  #   warp-on / warp-off aliases live in fish (modules/shell.nix note).
  # First-time setup: warp-cli registration new
  # This is guarded too: a release that nixpkgs marks insecure is omitted
  # instead of re-enabling every known-vulnerable package globally.
  services.cloudflare-warp.enable = warpPkg != null;
}
