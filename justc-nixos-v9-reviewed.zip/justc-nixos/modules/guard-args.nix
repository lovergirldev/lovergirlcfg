# modules/guard-args.nix
#
# Provides havePkgs / havePkg / missingPkgs to every other module.
#
# This file deliberately contains NOTHING but `_module.args` — no `options`
# block, no `config` block, no other top-level attribute. That is on purpose:
#
#   * A module that declares an explicit `options` block must put every other
#     attribute inside an explicit `config` block, or the module system rejects
#     it with "has an unsupported attribute '_module'". Keeping the args in
#     their own file makes that rule impossible to trip over.
#
#   * It also removes any chance of a loop between module ARGUMENTS and config
#     VALUES, since nothing here reads `config`.
#
# The option that collects the skipped names, and the reporting around it,
# lives next door in guard.nix.

{ lib, pkgs, ... }:

let
  # Nixpkgs can expose an attribute that throws when evaluated because the
  # package is broken, insecure, or unsupported on this platform. Catch that
  # case as well as a genuinely absent attribute so the safety net does what
  # its name promises.
  get = n:
    let
      raw = lib.attrByPath (lib.splitString "." n) null pkgs;
      attempt = builtins.tryEval (
        if raw == null
        then null
        else builtins.seq raw.drvPath raw
      );
    in if attempt.success then attempt.value else null;
  exists = n: get n != null;
in
{
  _module.args = {
    # havePkgs [ "foo" "bar.baz" ]  ->  [ pkgs.foo pkgs.bar.baz ], minus any
    # that do not exist. Use in place of `with pkgs; [ foo bar.baz ]`.
    havePkgs = names: lib.filter (pkg: pkg != null) (map get names);

    # missingPkgs [ ... ]  -> names absent or unavailable in this nixpkgs.
    missingPkgs = names: lib.filter (n: !(exists n)) names;

    # havePkg "foo" fallback  ->  pkgs.foo if it exists, else fallback.
    # Use in place of `pkgs.foo or fallback`, which still aborts if BOTH are
    # missing. Pass null as the fallback and filter the result.
    havePkg = n: fallback: if exists n then get n else fallback;
  };
}
