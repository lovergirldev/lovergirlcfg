# Requested GitHub repos — READ THIS BEFORE EDITING
#
# The twelve names you sent are three different KINDS of thing, and they get
# installed three different ways. Mixing them up is what breaks a flake, so
# they're separated here deliberately.
#
#   1. NIXPKGS PACKAGES        -> just an attribute below. Safe.
#   2. CLAUDE CODE MARKETPLACES-> NOT flake inputs. They have no flake.nix.
#                                 They're added at runtime with one command.
#                                 See the `claude-marketplaces` helper below.
#   3. NOT PACKAGED FOR NIX    -> need a derivation written and its hash
#                                 computed on a machine with network access.
#                                 Scaffolded and COMMENTED OUT so the flake
#                                 still locks and the install still completes.
#
# Nothing in this file can break `nix flake lock`. That was the design
# constraint: a broken lock kills the install at step 3, before the disk is
# even touched, and you'd be debugging it from a phone.

{ config, pkgs, lib, havePkg, missingPkgs, ... }:

let
  # Safe package lookup: if a package is absent or unavailable in this nixpkgs
  # revision, it is skipped and included in the `missingpkgs` report instead
  # of failing the whole rebuild. Check what landed with:  which claude
  maybe = name:
    let package = havePkg name null;
    in lib.optional (package != null) package;

  # ------------------------------------------------------------------
  # claude-marketplaces — adds the Claude Code plugin marketplaces.
  #
  # These are NOT Nix packages. anthropics/claude-plugins-official,
  # anthropics/claude-plugins-community and thedotmack/claude-mem are
  # marketplace repos consumed by Claude Code's own plugin system at runtime.
  # Adding them as flake inputs would fail — they contain a
  # .claude-plugin/marketplace.json, not a flake.nix.
  #
  # Run this once after first boot (needs network + a logged-in Claude Code):
  #     claude-marketplaces
  # ------------------------------------------------------------------
  claudeMarketplaces = pkgs.writeShellScriptBin "claude-marketplaces" ''
    set -uo pipefail

    if ! command -v claude >/dev/null 2>&1; then
      echo "claude-code isn't installed or isn't on PATH."
      echo "Check:  which claude"
      exit 1
    fi

    echo "Adding Claude Code plugin marketplaces..."
    for m in \
      anthropics/claude-plugins-official \
      anthropics/claude-plugins-community \
      thedotmack/claude-mem
    do
      echo "  -> $m"
      claude plugin marketplace add "$m" || echo "     (skipped — already added, or network/auth issue)"
    done

    echo
    echo "Done. Browse and install with:"
    echo "    claude plugin marketplace list"
    echo "    claude plugin install <plugin-name>@claude-plugins-official"
    echo
    echo "claude-mem is a plugin, not a package — install it from its"
    echo "marketplace once the above has run."
  '';
in
{
  justc.missingPackages = missingPkgs [ "claude-code" "lsfg-vk" ];

  environment.systemPackages =
    # ---------------- 1. in nixpkgs ----------------
    # claude-code: Anthropic's CLI. Guarded, so if the attribute name differs
    # in your nixpkgs revision the rebuild still succeeds and you just don't
    # get the binary. Search for the real name with:
    #     nix search nixpkgs claude
    (maybe "claude-code")

    ++ [
      claudeMarketplaces
    ]

    # ---------------- gaming, if present ----------------
    # lsfg-vk landed in nixpkgs for some revisions; guarded either way.
    # If this comes up empty, use the community flake noted below.
    ++ (maybe "lsfg-vk");

  # ==================================================================
  # NOT WIRED UP — needs work that can't be done blind
  # ==================================================================
  #
  # Each of these is a real project I verified exists, but none is packaged
  # in nixpkgs, and writing a derivation requires fetching the source to
  # compute its hash. A derivation with a guessed hash fails the build. So
  # they're documented here rather than shipped broken.
  #
  # ---- lsfg-vk  (github:PancakeTAS/lsfg-vk) ----
  # Lossless Scaling frame generation as a Vulkan layer.
  # IMPORTANT: it needs Lossless.dll from the real Lossless Scaling app,
  # which you must own on Steam. It is a hook into that, not a replacement.
  # There is a community NixOS flake for it — search GitHub for
  # "lsfg-vk nixos flake". Once you pick one, it becomes a normal flake
  # input plus one package line.
  #
  # ---- proton-forge  (github:theinvisible/proton-forge) ----
  # Qt/CMake DLSS + Proton manager for Steam games. Ships a .deb; no Nix
  # packaging upstream. Buildable with stdenv.mkDerivation + cmake + qt6,
  # but the src hash has to be computed with network access.
  #
  # ---- voice-training-ui  (github:scratchyone/voice-training-ui) ----
  # Voice training tool. No Nix packaging upstream. Check its README for the
  # runtime — if it's a web app, it may just be "run it with node/bun",
  # which needs no packaging at all.
  #
  # For any of the three, the fastest path on a working system is:
  #     nix run github:<owner>/<repo>          # if it exposes a flake
  # or clone it and build in a nix-shell. Once one actually works, tell me
  # and I'll bake in a proper derivation with the real hash.
}
