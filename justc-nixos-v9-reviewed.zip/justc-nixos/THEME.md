# justc — theme reference

Everything visual, in one place. All of it is plain text you can edit; niri,
waybar, rofi, ghostty and swaync reload without a rebuild.

## The system

| Layer | Choice |
|---|---|
| Base | ink `#0f1115` / `#16181d` / `#1c1f26`, line `#262a33` |
| Text | `#e3e5ea` primary, `#a8aeb9` secondary, `#878d99` muted (never pure white) |
| Accent (everyday) | light pink `#f3b8d1`, hover `#fad4e6`, dim `#cb87a3` |
| Accent (terminal family) | amber `#ffb26b`, hover `#ffc490`, dim `#c98a52` — see below |
| States | red `#e5715c`, green `#86c9a0`, yellow `#e8c07a` |
| UI font | Space Grotesk |
| Mono font | Rec Mono Linear, JetBrainsMono Nerd Font second (icons) |
| Material | translucent ink + real blur (niri 26.04 layer rules) |
| Controls | neumorphic: raised faces, pressed-in wells, active states press down |
| Radius | 8px (10–12 on big panels). Angular silhouettes, eased corners, no pills |
| Focus | shadow only + unfocused windows dim to 94%. No rings, no borders |
| Icons | Colloid pink (dark) · Cursor: Posy |
| Terminal background | Plain translucent glass; optional `ghostty/backgrounds/space.png` is shipped but disabled |
| Plasma default | Oxygen Dark (Plasma 6.7's revived KDE 4 theme), applied once at first login |

Honest note on neumorphism: waybar and swaync are GTK, so they get true
inset/outset shadows. rofi's theme engine has no shadow support, so the
applets and menus express the same idea with layered surfaces — raised rows on
a recessed title well — plus niri's own drop shadow behind the window.

## Where each piece lives

| Piece | File |
|---|---|
| Compositor, keybinds, blur, shadows | `~/.config/niri/config.kdl` |
| Bar layout | `~/.config/waybar/config.jsonc` |
| Bar looks | `~/.config/waybar/style.css` |
| Terminal | `~/.config/ghostty/config` |
| Terminal background image | `~/.config/ghostty/backgrounds/space.png` |
| Prompt | `~/.config/starship.toml` |
| Launcher (adi type-7 / style-1) | `~/.config/rofi/launchers/type-7/style-1.rasi` |
| Power menu (adi type-6 / style-3) | `~/.config/rofi/powermenu/type-6/style-3.rasi` |
| Applets (type-5, vertical) | `~/.config/rofi/applets/type-5/style-5.rasi` |
| **All rofi colors at once** | `~/.config/rofi/shared/colors.rasi` |
| Notifications | `~/.config/swaync/style.css` |
| Lock screen | `~/.config/hypr/hyprlock.conf` |
| File manager | `~/.config/yazi/theme.toml` |
| GTK apps | `~/.config/gtk-3.0/settings.ini`, `gtk-4.0` |

Two accent families, not one exception:

**Terminal family — amber `#ffb26b`.** Anything you'd see during a shell
session: `ghostty/config` (`foreground`), `starship.toml` (prompt symbols +
directory), and `dotfiles/yazi/theme.toml` (file manager). Edit the hex in all
three to change it. Reads
as a classic amber CRT — normal text is amber, and ghostty's 16-color ANSI
palette underneath is untouched, so `ls`, git status, and any app's own
colors still read exactly as before.

**Everyday family — light pink `#f3b8d1`.** Everything outside a terminal:
edit `accent` in `rofi/shared/colors.rasi`, then the same hex in
`waybar/style.css`, `eww/eww.scss` (`$accent`), `hyprlock.conf`,
`swaync/style.css`, and the Limine `term_palette` in `hosts/justc/boot.nix`
(the boot menu, seen once at power-on, counts as "outside a terminal").
Six files, one value.

The GTK/icon side of the pink family comes from Colloid's own `pink` variant
(`modules/desktop.nix`, `themeVariants`/`colorVariants`), not a hex edit —
Colloid ships a real pink preset, so this isn't guaranteed to be a pixel-exact
match to `#f3b8d1`, the same way the old orange wasn't a guaranteed match to
`#ffb26b` either.

## Keybinds

| Key | Does |
|---|---|
| `Mod+T` / `Mod+Return` | ghostty |
| `Ctrl+Alt+T` | alacritty — **works even if the Super key is disabled** |
| `Mod+E` | yazi (files) |
| `Mod+D` | launcher |
| `Mod+X` | power menu |
| `Mod+V` | clipboard history |
| `Mod+;` | emoji picker |
| `Mod+N` | notification centre |
| `Mod+Alt+L` | lock |
| `Mod+Shift+V/B/I/N/M/Q/S` | volume · bluetooth · battery · brightness · media · quicklinks · screenshot |
| `Print` | screenshot (niri's own UI) |
| `Mod+Shift+/` | full cheatsheet |

## Live design tools

    ghostty +list-themes                # terminal theme browser
    GTK_DEBUG=interactive waybar        # live CSS on the running bar
    rofi-theme-selector                 # browse installed rofi themes
    bar                                 # alias: reload waybar after a CSS edit

## After a theme edit

niri and waybar reload on save. To keep an edit permanently, copy it back into
the repo and rebuild:

    dots        # alias: copies ~/.config edits back into ~/nixos/dotfiles
    nrs         # rebuild

To reset every dotfile to the shipped version:

    bash ~/nixos/dotfiles/link.sh

## The theme applies itself

There is no post-install theming step. A service called `theme-apply` runs at
every login: it looks up what the GTK, icon and cursor packages actually
installed themselves as, writes those exact names into `gtk-3.0/settings.ini`,
`gtk-4.0/settings.ini` and gsettings, and fixes niri's cursor line to match.

That matters because these package folder names drift between nixpkgs
revisions — `Colloid-Pink-Dark` one month, `Colloid-pink-dark` the next.
Hardcoding them is how a theme silently half-applies. Detecting them can't.

It **merges** into those two settings.ini files rather than overwriting them:
it owns the six theme-name keys and preserves every other line you add. The
repo no longer ships its own copies of those files, because two sources of
truth for one file is what made hand edits vanish at every login.

Run it by hand after any theme package change:

    theme-apply

It prints what it picked, e.g. `theme-apply: gtk=Colloid-Pink-Dark
icons=Colloid-pink-dark cursor=Posy_Cursor`. If a name looks wrong, the
fallback chain went one step too far — save that line when asking for help.

Verify fonts landed:

    fc-list | grep -iE 'grotesk|rec mono' 

## Wallpaper

Drop any image at `~/Pictures/wall.png` (or `.jpg`) — niri loads it at login.
Change it live:

    swww img ~/Pictures/whatever.jpg --transition-type grow --transition-fps 60
