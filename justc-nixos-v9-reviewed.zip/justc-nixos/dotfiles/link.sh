#!/usr/bin/env bash
# Copies these dotfiles into ~/.config as REAL FILES (deliberate: no symlinks,
# so nothing dangles if ~/nixos moves). Every replaced path is copied to one
# timestamped backup tree first. Safe to re-run any time — this is the
# "my theming broke, reset it" button.
set -euo pipefail

DOTS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CFG="$HOME/.config"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"
BACKUP_ROOT="${JUSTC_DOTFILES_BACKUP:-$HOME/.local/state/justc-dotfiles/backups/$RUN_ID}"
BACKUP_USED=0

case "$HOME" in
  /*) ;;
  *) echo "link.sh: HOME must be an absolute path" >&2; exit 1 ;;
esac
[ "$HOME" != "/" ] || {
  echo "link.sh: refusing to operate with HOME=/" >&2
  exit 1
}
HOME_REAL="$(realpath -m "$HOME")"
BACKUP_REAL="$(realpath -m "$BACKUP_ROOT")"
case "$BACKUP_REAL" in
  "$HOME_REAL"/*) ;;
  *) echo "link.sh: backup path escaped HOME: $BACKUP_ROOT" >&2; exit 1 ;;
esac

copy() { # copy <repo-path> <target-path>
  local src="$DOTS/$1" dst="$2" relative backup parent_real

  [ -e "$src" ] || {
    echo "link.sh: source is missing: $src" >&2
    return 1
  }
  case "$dst" in
    "$HOME"/*) ;;
    *) echo "link.sh: target escaped HOME: $dst" >&2; return 1 ;;
  esac
  parent_real="$(realpath -m "$(dirname "$dst")")"
  case "$parent_real" in
    "$HOME_REAL" | "$HOME_REAL"/*) ;;
    *) echo "link.sh: target parent resolves outside HOME: $dst" >&2; return 1 ;;
  esac

  mkdir -p "$(dirname "$dst")"
  if [ -e "$dst" ] || [ -L "$dst" ]; then
    relative="${dst#"$HOME"/}"
    backup="$BACKUP_ROOT/$relative"
    mkdir -p "$(dirname "$backup")"
    cp -a -- "$dst" "$backup"
    BACKUP_USED=1
    rm -rf -- "$dst"
  fi
  cp -a -- "$src" "$dst"
  echo "copied  $dst"
}

copy niri/config.kdl        "$CFG/niri/config.kdl"
copy waybar/config.jsonc    "$CFG/waybar/config.jsonc"
copy waybar/style.css       "$CFG/waybar/style.css"
copy waybar/scripts         "$CFG/waybar/scripts"
copy ghostty/config         "$CFG/ghostty/config"
copy ghostty/shaders        "$CFG/ghostty/shaders"
copy ghostty/backgrounds    "$CFG/ghostty/backgrounds"
copy fastfetch              "$CFG/fastfetch"
copy eww                    "$CFG/eww"
copy fish/config.fish       "$CFG/fish/config.fish"
copy starship.toml          "$CFG/starship.toml"
copy rofi                   "$CFG/rofi"
copy hypr/hyprlock.conf     "$CFG/hypr/hyprlock.conf"
copy hypr/hypridle.conf     "$CFG/hypr/hypridle.conf"
copy swaync/config.json     "$CFG/swaync/config.json"
copy swaync/style.css       "$CFG/swaync/style.css"
copy yazi/yazi.toml         "$CFG/yazi/yazi.toml"
copy yazi/theme.toml        "$CFG/yazi/theme.toml"

# NOTE: gtk-3.0 / gtk-4.0 settings.ini are deliberately NOT copied here any
# more. theme-apply owns the theme-name keys in those files and merges into
# whatever else is present, so shipping a competing copy just caused the two
# to fight (old bug 3). Run `theme-apply` to regenerate them.

chmod +x "$CFG"/rofi/launchers/*/*.sh "$CFG"/rofi/powermenu/*/*.sh \
         "$CFG"/rofi/applets/bin/*.sh "$CFG"/waybar/scripts/*.sh "$CFG"/eww/scripts/*.sh 2>/dev/null || true
mkdir -p "$HOME/Pictures/Screenshots"

echo
if [ "$BACKUP_USED" -eq 1 ]; then
  echo "backup: $BACKUP_ROOT"
fi
echo "done. In niri, everything but GTK reloads on save; log out/in for the rest."
