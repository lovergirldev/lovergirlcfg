#!/usr/bin/env bash
## Power menu — type-6 / style-3
## Lock / Logout / Suspend / Reboot / Shutdown, with a yes-no confirm.

dir="$HOME/.config/rofi/powermenu/type-6"
theme='style-3'

uptime_str="$(uptime -p 2>/dev/null | sed 's/^up //')"
host="$(cat /etc/hostname 2>/dev/null || echo justc)"

lock='󰌾'
logout='󰍃'
suspend='󰤄'
reboot='󰜉'
shutdown='󰐥'
yes='󰄬'
no='󰅖'

chosen="$(printf '%s\n%s\n%s\n%s\n%s' "$lock" "$logout" "$suspend" "$reboot" "$shutdown" \
    | rofi -dmenu -theme "${dir}/${theme}.rasi" -p "  ${host} — up ${uptime_str}")"

confirm() {
    local answer
    answer="$(printf '%s\n%s' "$yes" "$no" \
        | rofi -dmenu -theme "${dir}/${theme}.rasi" -p "  $1?")"
    [ "$answer" = "$yes" ]
}

case "$chosen" in
    "$lock")     hyprlock ;;
    "$logout")   confirm "Log out"  && { niri msg action quit -s 2>/dev/null || loginctl terminate-user "$USER"; } ;;
    "$suspend")  confirm "Suspend"  && systemctl suspend ;;
    "$reboot")   confirm "Reboot"   && systemctl reboot ;;
    "$shutdown") confirm "Shut down" && systemctl poweroff ;;
esac
