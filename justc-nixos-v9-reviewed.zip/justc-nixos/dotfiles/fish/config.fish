set -g fish_greeting ""

if status is-interactive; and type -q starship
    starship init fish | source
end

# ---- NixOS ----
alias nrs "sudo nixos-rebuild switch --flake ~/nixos#justc"   # rebuild
alias nup "cd ~/nixos; and nix flake update; and nrs"          # update everything
alias ngc "sudo nix-collect-garbage --delete-older-than 14d"   # reclaim space

# ---- VPN toggles (never connect both at once) ----
alias warp-on  "warp-cli connect"
alias warp-off "warp-cli disconnect"
# mullvad: use the GUI, or `mullvad connect` / `mullvad disconnect`
# the waybar VPN widget enforces the one-at-a-time rule for you

# `conserve on|off` (battery charge cap) is a system script — see legion.nix

# ---- Flatpak ----
# The Flathub remote is added automatically on first boot.
alias fpi "flatpak install flathub"
alias fps "flatpak search"
alias fpu "flatpak update"
alias fpl "flatpak list --app"

# ---- fetch ----
# neofetch is archived upstream; fastfetch is the maintained successor and
# reads ~/.config/fastfetch/config.jsonc (nix logo, trans flag colours).
alias neofetch "fastfetch"
alias ff "fastfetch"

# ---- editors ----
# `nvim` = plain Neovim, your own ~/.config/nvim (untouched).
# (`nvix` / nixvim was removed in session 5 — plain `nvim` is your editor.)

# ---- files / theming helpers ----
alias y "yazi"
function dots
    cp ~/.config/niri/config.kdl ~/nixos/dotfiles/niri/config.kdl
    and cp -a ~/.config/waybar/. ~/nixos/dotfiles/waybar/
    and cp ~/.config/ghostty/config ~/nixos/dotfiles/ghostty/config
    and cp -a ~/.config/fastfetch/. ~/nixos/dotfiles/fastfetch/
    and echo "dotfiles copied back to ~/nixos"
end
alias bar "killall -SIGUSR2 waybar"          # reload waybar after a CSS edit
alias ew "eww reload"                        # reload applets after an scss edit
alias ewr "eww kill; and eww daemon"         # hard restart if eww gets stuck
alias theme-list "ls /run/current-system/sw/share/themes /run/current-system/sw/share/icons"
# plasma-oxygen  — re-apply Oxygen Dark in the KDE session (runs itself once at
#                  first login; safe to run again any time)
# claude-marketplaces — add the Claude Code plugin marketplaces (needs network)

# ---- boot ----
# Limine's module can place limine.conf in more than one supported ESP path.
function bootcfg
    set -l cfg (find /boot -maxdepth 5 -type f -iname limine.conf 2>/dev/null | head -n 1)
    if test -n "$cfg"
        sudo cat "$cfg"
    else
        echo "limine.conf not found below /boot" >&2
        return 1
    end
end
alias espfree "df -h /boot"                   # ESP is 1G; config keeps 5 generations
